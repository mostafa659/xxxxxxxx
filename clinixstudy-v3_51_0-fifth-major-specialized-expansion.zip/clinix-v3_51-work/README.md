## v3.51.0 — Fifth Major AI-Error-Driven Specialized Expansion (34 new records)

The fifth expansion adds 34 narrowly scoped, source-backed specialist records, bringing the bundled specialist corpus to 80 records. The batch is grounded in seven declared sources: a Swiss neonatal EOS guideline, two diabetic-foot infection/osteomyelitis reviews, a 2026 multi-source clinical evidence-QA benchmark, a 2026 biomedical-statistics framework, and two official CDC ACIP GRADE handbook chapters. All 34 records remain `draft`; exact source/quotation provenance does not equal clinical approval.

- **Neonatal early-onset sepsis (10):** Swiss-only EOS pathway boundaries, serial exams, asymptomatic risk, respiratory-distress context, prematurity, pre-antibiotic culture, antibiotic reassessment, biomarker limitations, residual risk, and lumbar-puncture indications. Retrieval requires Switzerland and neonatal context; these recommendations must not be generalized to other jurisdictions.
- **Diabetic foot infection / osteomyelitis (11):** local microbiology and resistance variation, avoiding universal empirical Pseudomonas coverage, multimodal diagnosis, bone-biopsy limitations, deep culture/imaging, source control, culture-directed therapy, off-loading, histology/culture discordance, and the distinct contributions of histology and microbiology. Population-specific figures are not universal test characteristics.
- **Evidence synthesis and biomedical statistics (6):** separate “no evidence” from a negative finding, interpret odds-ratio confidence intervals correctly, avoid single-sentence anchoring, preserve low certainty, distinguish statistical from clinical importance, and separate effect estimate/effect size/CI/p-value.
- **GRADE evidence appraisal (7):** outcome-level certainty, downgrading domains, upgrading non-randomized studies, RCT upgrade exception, conditional ROBINS-I exception, critical-outcome synthesis, and the lowest-certainty critical outcome rule in the ACIP handbook.

**New prompt safeguard:** Evidence-appraisal rules activate only for literature, guideline, statistics, and evidence-synthesis queries. They require whole-source synthesis, preserve uncertainty, distinguish absence of evidence from evidence of no effect, use the correct null value for ratio versus difference measures, and keep statistical significance separate from clinical importance. Neonatal context inference was also corrected so newborns are not collapsed into generic pediatric population matching.

**Public model-evaluation audit:** `docs/AI_MEDICAL_MODEL_AUDIT_2026.md` summarizes public 2026 benchmarks and systematic reviews, their limits, and the resulting error taxonomy. This is a structured audit of published evidence—not a claim to have inspected every private medical answer worldwide.

Validation: strict builder accepted 34/34 and rejected 0; all new records remain draft and are excluded from student retrieval. Full project test suite: **411/411 passed**. Vite production build was not run because dependencies (`node_modules`) are not installed in this workspace. No live Gemini/API benchmark was run in this release.

---

## v3.50.0 — Major AI-error-driven specialist expansion (24 new records)

Largest specialist-library expansion in this project so far: 24 additional, narrowly scoped draft records, increasing the bundled specialist corpus from 22 to 46 entries. The batch is divided into four focused domains, grounded in four peer-reviewed CC BY 4.0 sources, with passage-level quotation provenance and individual applicability/exception fields.

- **Dental anaesthesia / LAST (11):** additive toxicity across amide agents; fractional-dose calculations; third-agent and vasoconstrictor accounting; jurisdiction-dependent maximum doses; atypical/delayed LAST; vasovagal/adrenaline differentials; sedation-masked prodrome; altered protein binding; bupivacaine/CCB pharmacodynamic interaction; airway-first rescue hierarchy.
- **FH-deficient renal cancer / HLRCC (7):** hereditary versus sporadic distinction; nomenclature boundary; fumarate–PHD–HIF pseudohypoxia; α-KG dioxygenase and epigenetic effects; fumarate non-specificity; histology limits; KEAP1–NRF2 branch.
- **Veterinary MDR1 / ABCB1 (4):** canine versus feline mutation differences; cohort-limited feline allele frequency; transporter loss-of-function evidence; in-vitro inhibitor assay versus clinical dosing boundary.
- **Warfarin precision pharmacology (2):** interaction-effect variability and genotype-plus-clinical-covariate algorithms.

**Error-driven safeguard added to the specialist prompt:** patient-specific laboratory values, vital signs, imaging, histology and history must come from the actual question; literature cohorts, case reports, mechanisms and in-vitro values cannot be restated as findings in the current case. Calculations must use supplied inputs and explicit units; mechanisms or associations alone do not prove diagnoses or variants; numerical data must not cross species, assays or jurisdictions without direct evidence.

All 24 records remain **draft**. Their source/license/exact-quote checks establish provenance only—not medical correctness. A named qualified reviewer must approve claim support, clinical accuracy, scope and exceptions before retrieval can expose an entry to students. The general safety KB remains a separate layer. No live Gemini A/B benchmark or Vite production build is claimed in this release.

Review file: `knowledge/specialized/major-expansion-2026/AUDIT.md`.

## v3.48.0 — Focused Pharmacogenomics Expansion (10 new draft entries)

Patch release based on v3.47.0. The first seven-record FDA pilot is preserved unchanged. A separate lazy-loaded expansion adds ten tightly scoped entries from the FDA Table of Pharmacogenetic Associations (current page checked 2026-11-20; update history includes 2026-09-10) plus the open-access 2026 CERSI-PGx UGT1A1/irinotecan guideline.

- **Oncology:** DPYD/complete-versus-partial DPD deficiency for capecitabine and fluorouracil; UGT1A1/irinotecan phenotype and toxicity distinctions. The capecitabine and fluorouracil guidance is deliberately separate because FDA wording differs.
- **Cardiovascular / pharmacology:** CYP2C19/clopidogrel active-metabolite response; CYP2D6 + concomitant CYP3A4 inhibition with propafenone; CYP2C9 poor-metabolizer contraindication for deuruxolitinib.
- **Anesthesia:** BCHE/succinylcholine prolonged blockade; RYR1/CACNA1S susceptibility with the four FDA-listed trigger agents.
- **Neurotherapeutics:** APOE ε4/ε4 risk framing for lecanemab and donanemab. These are benefit–risk risk modifiers, not automatic contraindications in this FDA table.
- Every new record is **draft**. Builder-verified source/license/quote provenance does not mean that a clinician has approved the complete clinical claim. Draft entries remain excluded from student retrieval and prompts until a qualified reviewer approves claim support, accuracy, scope and exceptions.
- No Gemini A/B benchmark was run in this release; no accuracy improvement is claimed.

Review file: `docs/knowledge/specialized-expansion-2026-09-review.md`. Source manifest and candidates are under `knowledge/specialized/pharmacogenomics/`.

## v3.47.0 — First Curated Pharmacogenomics Knowledge Pilot

Patch release based on v3.46.0. The specialized layer is intentionally **small and high-value**; it is not a second textbook and does not duplicate facts a general medical model usually answers correctly.

- Accepted globally applicable expert categories: rare mechanisms, complex relationships, specialist diagnostic interpretation, technical distinctions, context-sensitive quantitative data, species-specific knowledge and non-obvious exceptions. Country, institution, exam, protocol and recent-guideline entries remain supported too.
- Each entry explains its incremental value beyond ordinary model knowledge, its clinical scope, applicability conditions, exceptions, source passages, review status and expiry/review date. Generic textbook facts remain rejected.
- The builder's `verified` / `sourceVerified` / `quoteVerified` flags mean **source, license and exact-quote provenance only**. They do not claim that a quote proves the medical statement. Approved entries additionally require an explicit human review checklist for claim support, clinical accuracy, and scope/exceptions.
- Context is fail-closed: a species-, population-, age-, sex-, pregnancy-, exam-, institution- or jurisdiction-specific entry is not retrieved when its required context is missing or mismatched.
- `analysis.js` enriches question solve and answer-writing prompts with up to three retrieved specialist references (or a small profile-scoped candidate shelf for image-only questions). English and Arabic patient-context cues are recognized for species, age, sex and pregnancy; missing declared context still fails closed. The prompt tells the model to apply a reference only after matching the case and all applicability conditions. This adds no model request and does not expose library bookkeeping to students.
- A first compact pilot contains seven FDA-sourced pharmacogenomics entries: evidence-tier interpretation, table-inclusion/testing distinction, HLA-B*57:01/abacavir, CYP2C9/aficamten, MT-RNR1/aminoglycosides, TPMT/NUDT15/azathioprine, and HLA-B*15:02/carbamazepine. All remain `draft` and are excluded from production retrieval until a qualified human clinical reviewer approves each claim, source support, scope and exceptions.
- A paired Gemini A/B benchmark compares the same seven questions without and with the draft specialist references. It makes 14 calls, blinds the answer condition, stores the condition key separately, and includes a scoring rubric. No benchmark lift is claimed until actual Gemini calls are run and outputs are independently scored.
- Run `npm run kb:pilot` with `GEMINI_API_KEY` set to perform the comparison; `npm run kb:pilot:prepare` prepares prompt pairs without API calls.

## v3.44.0 — Calibrated Citation-First Trust · High-Yield KB (542 concepts)

**Frozen contracts, unchanged:** `tests/baseline/v3.42-budget.json` and `tests/baseline/v3.42-solve-output.json` are untouched; every prompt is still at or below v3.42; no request, token or wait was added (the exam still makes exactly the 2 requests v3.42 makes with an attached file — measured on the v3.42 code — and 1 without). Everything below is local, on-device code.

### Pillar 1 — Citation-first calibrated trust
**One tag per exam item (and per lesson sentence), strongest evidence first:**

| tag | meaning | saved mistakes | memorize |
|---|---|---|---|
| ✓ `verified` | a verified, current KB reference agrees | saves smoothly | yes |
| 📄 `grounded` | the key / sentence is anchored in **the student's own source**: «From your PDF · p. 3» + the snippet | saves smoothly | yes — unless it is safety-critical (dose, contraindication): then it needs an official reference |
| 🔎 `reference` | a KB rule agrees, its source check is pending (was `pending`) — or the key is anchored only in the student's **saved AI-written lessons** | saves smoothly | no |
| ⚠ `conflict` | the reference contradicts the item · the student's notes differ (a number or a negation) · **the source itself contradicts the reference** («source says X, reference says Y») | held back + one-tap «save anyway» | no |
| ؟ `ungrounded` | nothing anchors the key (the generator's own claim), or the item is defective, or a safety-critical statement is unresolved | held back + one-tap «save anyway» | no |

Precedence: conflict > defect > ✓ > 📄 > 🔎 > ؟. Legacy tags map: `pending → reference`, `unverified → ungrounded`. «Act, then review»: anything anchored in the KB or in the student's own file saves without friction, carries its badge (with page for a PDF) and can be removed in one tap («شيله من غلطاتي»); only conflict / ungrounded items are held back, because for them the key itself may be wrong.

**How grounding works (`provenance.js groundSentence`)**, zero tokens: an inverted index word → sentence over the source model (typed text, Word/PowerPoint/EPUB, audio transcripts, a PDF's text layer by page, a *complete* OCR transcript). A claim is grounded when one source sentence (or two adjacent ones) holds ≥ 75 % of its anchor words **and** three guards pass: every number is in the source sentence (else *contradiction: number*), the negation agrees (else *contradiction: polarity*), every ALL-CAPS token appears (else *not grounded*: the acronym is the invention). For an exam item the key is grounded through (1) the rationale sentences about the key option, (2) the option itself, (3) stem + option as one proposition. Model-written text (a study "map", the solve brief) is **never** searched: it can fill a gap in the index but cannot ground a claim; scanned PDFs / unread images ground nothing. Unknown origin is never promoted.
Also fixed on the way: a word-boundary bug where *nutrient* / *patient* ended in "-nt" and were read as negations (explicit negation list now).

### Pillar 2 — the KB: 542 concepts, lazy, indexed, audited
**489 concept rules + 38 reference ranges + 15 anatomy / scope / framework facts.** Domain breakdown of the rules: **antidotes 29 · drug classes 66 · drug effects & safety 81 · physiology (acid–base, electrolytes, autonomic, endocrine, cardiac, renal) 51 · clinical (rhythms, shock, emergencies, neuro, GI, renal, haematology) 85 · nursing (isolation, safety, maternal–child, paediatrics, mental health) 67 · anatomy (counts, heart, brain, cranial nerves, glands) 70 · microbiology / immunology 40.** By form: 214 sign rules, 81 effect, 66 class, 57 treatment, 29 antidote, 23 physiology, 17 counts, 2 cord, 3 136 truth terms and ~15 600 wrong-term checks (slot-derived). Arabic: 25 rules carry Arabic subject aliases and the cue lists have Arabic words; the *truth / wrong terms are mostly English* because medical terms in Arabic notes are written in English.

**Anti-collision design** (`kb/rules.js`) instead of 489 regexes or free-text triggers:
- a rule is data: **subject** (required anchor) · optional **cue** (context) · **truth** · **wrong** (explicit list, or `@` = the truths of the other rules of the same slot — «antidote for heparin is vitamin K» is caught because vitamin K is warfarin's antidote, authored once) · per-rule **skip** words (withdrawal, bridging, second-line…);
- a conflict fires only if: subject ∧ cue ∧ a wrong term *near* the subject and *outside* the subject phrase ∧ no truth term ∧ **no negation anywhere between them** ∧ no skip word ∧ **the wrong term's owner is not also in the sentence** (a comparison) — for slot lists and explicit lists alike;
- numeric rules conflict only when numbers sit next to the noun and **none** equals the value (a range like «3 to 15» is not a count);
- lab ranges: sex/age strata, SI + conventional units, directional words («hypokalemia (K 6.1)»), unit-less pH / INR / K / Na, and a **10 %-of-range boundary tolerance** so a dispute about a limit is never an error;
- lookup: token → rule-ids inverted index, so a sentence touches ~2–3 % of the rules. Verb forms, plural «-es», the article «the» and the Arabic «ال» are normalised the same way for rule terms and sentences.

**The audit (`npm run kb:audit`, in the suite) — what it proves:** 0 duplicate / colliding rules (a subject has one antidote / one class; no truth is another rule's wrong term for the same subject); **a generated sentence for every rule — its truth never conflicts with ANY rule, and one of its wrong terms is caught by that rule — 0 unreachable rules**; the negated / compared / "and"-joined version of every wrong claim never fires; **84 hand-written correct statements (comparisons, negations, withdrawal, second-line, massive-bleed…) → 0 false conflicts and 0 range conflicts, no patches**; **75 hand-written classic errors → 75 caught** and patched in place. Writing the audit found and fixed ~25 rule bugs (truth words hiding in subject names, comparative sentences, stray `;` in fix texts that had been corrupting skip lists, `lower` as a skip word, …).

**Medical rigor, honestly:** I removed rules I could not call universal (labetalol/carvedilol as "beta blockers", sotalol, diphenhydramine as non-anticholinergic, furosemide's sulfonamide status, amiodarone class, phenobarbital's two classes…). **Every rule is still `source.verified:false`** — written from standard textbook knowledge, no quotes extracted, so they back a statement as 🔎 *reference*, never ✓, and `build-kb.mjs` is the only path to ✓. The 2 CPR-figure rules sit in a `-guideline` domain (AHA/ERC; may change). **I am not a substitute for clinical review: have a clinician read `src/lib/kb/modules/r-*.js` before relying on any rule.**

### Pillar 3 — measured (this VM: ONE vCPU, Node 22; your phone will differ)
- **Tests:** 333 (238 original + 43 v3.43 + 30 v3.43.1 + 8 KB audit + 14 citation). `npm test` now runs files one at a time (`--test-concurrency=1`): on one vCPU the parallel runner starves the timing tests.
- **Bundle (esbuild, minified, split):** every rule pack is its own lazy chunk — antidotes 3.9 KB, classes 8.3, drugs 29.4, physiology 26.5, clinical 39.9, nursing 26.0, anatomy 20.2, micro 14.1, ranges 13.6, digestive 14.4, scope 2.6 → **~199 KB raw, ~62 KB gzip, none in `main.js`** (grep-verified). The v3.43.1 KB was ~19 KB raw.
- **Load (background, off the first-render path):** ~100–160 ms in total, in tasks of ≤ ~35 ms with a yield between packs; the index build was 141 ms → 33 ms after making owner look-ups token-indexed.
- **Matching:** 1–5 µs per sentence (p95 ≈ 3 µs). Whole verification pass on a 2 343-word, 271-sentence lesson (a stress case: most sentences are high-risk): **warm median 9.5–11.6 ms, min 5.5 ms; cold first pass 59–89 ms** (hidden by the background warm-up). p95 of single runs on this VM is 27–33 ms because of GC spikes on one vCPU; the unit test judges the calmest of three 40-run batches and prints all three. So: **median < 20 ms yes, p95 < 20 ms not on this VM.**
- Tagging one exam item against a 40-page PDF-sized source: see the `# tag one exam item…` line of `tests/citation.test.mjs`.

### What is still unverified
- **Medical correctness of the 489 rules** beyond my own review and the self-consistency audit: no clinician reviewed them and no rule has a verified source quote. A rule that is wrong in a way the audit cannot see (a plausible but false textbook claim) would patch a *correct* sentence. Several rules (e.g. oral-bisphosphonate administration, ESI / START triage wording, tPA-in-hemorrhage, lithium sodium advice, CPR figures, ranges) are standard but **vary by guideline, country or lab**; they are labelled 🔎 reference, not ✓.
- **Real student material.** Grounding was tested on generated PDFs, typed text and mocked OCR text, not on a corpus of real lecture notes; paraphrase-heavy notes (a source that says the fact in different words than the item) will usually come out *ungrounded*, not wrongly grounded — the 75 % anchor threshold and the three guards are deliberately conservative, and the threshold was not tuned on data.
- **Distractors are not checked against the source** (a bag-of-words match cannot tell "liver makes bile" from "gallbladder … bile"), so an item with two defensible answers in the notes can still be tagged grounded. KB-side, a distractor the reference supports *is* flagged.
- Exam items are grounded against attached files and the saved lessons the exam was built from; **images attached to an exam have no text** and ground nothing unless an OCR transcript exists.
- Arabic: aliases and cue words exist for a quarter of the rules; Arabic-only sentences with Arabic wrong-terms are mostly **not** covered. The Arabic PDF order repair is a heuristic.
- The UI (ExamCard badges / snippet / remove, TrustPanel counts) parses and bundles with esbuild but was never rendered in a browser; Vite / Android / Electron builds were not run.
- `logprobs`, grounding in the proof request, calibration (no profile is calibrated, so nothing reaches HIGH), licences of any corpus, and the effect of the `PREMISE` line on accuracy: unchanged from v3.43.x and still untested.
- The 20 ms target is for matching and a typical lesson; see the p95 note above.


## v3.43.1 — the three accuracy gaps closed (PDF/image sources · exam generator · reasoning before the answer)

All three are active in the app and covered by tests (311 pass: the 238 original + 43 for v3.43 + 30 for v3.43.1). The frozen v3.42 budget baseline (`tests/baseline/v3.42-budget.json`) was **not modified**; every prompt is still at or below it.

### 1 · Part A for PDFs and images — one pipeline, no bypass
- **Provenance is attached at extraction time** (`lib/provenance.js`): every item gets `prov = {sourceType: text|audio|pdf|image, extracted, pages, chars, confidence, reason}` when it is read (`docs.js`); segments carry `page`, `block`, a running `index` and sentence boundaries normalised by the same splitter the output pass uses. Each checked sentence that comes from the source knows where (`item.prov = {sourceType, page, block, index}`).
- **PDFs: the text layer is read on the device** (`lib/pdftext.js`, no network, no tokens, ≤ 2.5 s, while the student adds the file): Flate / ASCII85 / ASCIIHex stream chains, compressed object streams, the page tree, text operators, `/ToUnicode` CMaps, NFKC, and Arabic visual-order repair. Tested on real PDFs made with reportlab (standard and embedded TrueType fonts), LibreOffice (Arabic + English) and qpdf (object streams), plus a scanned PDF. Gemini still receives the PDF natively; the token count is unchanged.
- **One source model for every type**: typed text, Word/PowerPoint/Excel/EPUB, audio transcripts, a PDF's text layer, an OCR transcript all enter `verifyText()` as the same `sourceModel`. A test feeds identical content as text, as a PDF and as an OCR transcript and asserts identical cleanup, stripping and KB patches, for all 20 seeded errors.
- **No unknown-means-source loophole**: the old code treated "no source text" as "everything is from the source". Now origin stays *unknown*; an invented mnemonic/framework is removed, nothing is memorize-eligible without ✓, and the model is flagged `strict`. Scanned PDFs and unread images run in this mode. KB patches, the analogy box, residue cleanup and reference cards run regardless.
- A bug the end-to-end test found and fixed: a mnemonic that copied the source's wording but swapped the acronym (`CFBP` → `QQZZ`) scored as "from the source". For mnemonics and frameworks the acronym tokens must now appear in the source. Also: the extraction stage's text is model-written, so it only fills a gap and is never added next to real source text.
- **Extracted text is cleaned like any other** (`cleanResidue` on the OCR text and on the study "map" shown to the student). The *source* is checked against the KB for every type and part («source says X, reference says Y»); it is **not silently rewritten** — patching what an OCR transcript says would falsify what the image said.
- Limits (reported, never guessed): scanned pages and images have no text layer, so for them the source is the OCR transcript when that stage ran (a full source), otherwise the solve brief or the study map (partial → strict). Fonts without a `ToUnicode` map, encrypted files, LZW/other filters and text drawn in XObject forms are not read (confidence drops, strict mode applies). The Arabic order repair is a heuristic (word-start «ال» vs word-end «لا»). The extractor was verified on generated fixtures, **not on a corpus of real-world PDFs**.

### 2 · The exam generator is inside the accuracy layer (`lib/examtrust.js`)
- Every item is evaluated **and tagged before the student sees it**, synchronously, with zero extra requests (a test counts them: one batch = one request): residue cleanup; KB patches in the stem and rationale (before → after kept in `trustPatches`); lab range by sex/age; other-profession and other-country rules; structure checks (distinct options, valid key, one key for single / ≥ 2 for multi, "select N" = N); the key against the KB; a "wrong" option the reference says is true; unresolved safety-critical statements; expired references.
- Tag `q.trust`: `verified` (a verified, current fact agrees with the key) · `pending` (= «reference — source check pending») · `unverified` (nothing resolved the key, or something is contradicted / unresolved). The reason list is in `q.trustWhy`. An item that was shown is never rewritten later (tested). Exams saved before this version are tagged once when opened.
- **Saved mistakes** skip `unverified` automatically (`recordAnswer` → `"skipped"`; the card says why and offers «احفظه على أي حال» as the student's own choice). `verified` and `pending` are saved. Memorize stays ✓-only. This is a deliberate difference from the v3.43 note «✓ only»: a saved mistake needs a key some reference agreed with, memorize needs a verified one.
- Unresolved high-risk claims of exam items go to the KB gap list. The F3 claims-in-the-proof-request check is **not** applied to exams: items are final when shown, so a late verdict could not change them.
- Consequence to know: with the current seed KB almost every generated item will be `unverified` or `pending` (the KB covers little), so «saved mistakes» from the exam generator will mostly need the manual override until the KB grows.

### 3 · Reasoning before the answer (the budget kept)
- The solve brief is now `PREMISE` (≤ 20 words, 1–2 clauses) → `ANSWER` → `TYPE` → `KEYWORD` → `CONCEPTS` → `DATA` → `OPTIONS` → `CALC` → `CONFIDENCE`. The prompt says reasoning comes before the commitment. `parse.js` is unchanged; `parseBrief` reads the premise, cuts it at 24 words, and knows whether it came first; the lesson writers receive it with the `TIER`. The thinking budget (`MODES[*].solve.budget`) and `maxOut` are unchanged (tested).
- A brief with no premise, or one written after the answer, is capped at MEDIUM even for a calibrated profile. The logprob search for the `ANSWER` token is anchored to a line start, so premise text cannot be mistaken for it.
- **Budget, measured** (`tests/solveorder.test.mjs`): prompt tokens v3.42 1022 → 935 (NCLEX profile line included) / 758 (generic). Worst-case *output words* (read from the caps in the prompt, against the v3.42 caps frozen in `tests/baseline/v3.42-solve-output.json`): 5 options 147 → 129 (140 with CALC), 6 options 165 → 144 (155 with CALC). To pay for the premise the option reasons were cut from 18 to 15 words, the keyword from 12 to 10, DATA to 24 words (10 when CALC is used).
- **What is NOT known**: whether the premise actually improves accuracy on multi-step priority questions, and whether the answer-token probability stays as well calibrated after a premise. Both need the golden-set A/B (`scripts/calibrate.mjs`) that no profile has yet. It was implemented as specified and is not claimed to be better.

### Verified in this build
- 311 tests pass. All JSX parses and the whole app bundles with esbuild (imports resolve; the KB modules land in separate lazy chunks, none in the startup bundle).
- Deterministic layer: warm median ≈ 5–8 ms on a ~2000-word lesson; the p95 is judged on the calmest of three 40-run batches because this build VM has one vCPU and the first batch spikes (24–34 ms) while the JIT warms. The app warms it in the background (`ensureKb`). On a slow phone the first pass may exceed 20 ms.

## v3.43.0 — Accuracy Architecture (one shared design for source-based content and question analysis)

**What this version guarantees, and what it does not.** No LLM can be made error-free. v3.43 guarantees only this: *no high-risk claim or answer is shown as certain unless verified knowledge or a code check resolved it; everything else is visibly labeled and kept out of "memorize" and saved mistakes.* Nothing in the app claims 100 % correctness, and nothing here asks a model "are you sure?".

### Constraints and how they are met
| Constraint | How |
|---|---|
| C1 no slower first result | No new blocking request. The KB loads in the background; labels and patches are applied at the *final* text (streamed text appears exactly as before, then is patched in place). A static test checks that nothing in `analysis.js` awaits the accuracy layer. |
| C2 no more tokens / requests | Every prompt is **smaller** than v3.42 (`tests/budget.test.mjs`, frozen baseline `tests/baseline/v3.42-budget.json`; solve 1022 → 665 tokens, lesson prompts −235…−357). Output caps, thinking budgets and request counts are unchanged (the 238 old engine/speed/latency tests still pass). Claims ride inside the existing proof request and the chunk gives up exactly the room they take. Small free keys: proof is skipped, so zero added requests; logprobs are probed **once per model on any key** (audit fix #2) on the solve request itself, so the probe adds no request, and the verdict (supported / refused with a 400 / silently omitted) is cached. |
| C3 labels, not promises | `✓ verified` · `⚠ corrected / uncertain / possibly outdated / reference pending / other-profession rule` · `؟ unverified`. Memorize and saved mistakes accept only ✓ (plus plain, low-risk text copied from the source). |
| C4 no self-revision | None added. Second opinion (B7) is user-initiated, uses a *different* model with shuffled options, scored by token probability. |

### What was built (files)
- `lib/profile.js` (P1) — profile = {discipline, exam, region, languages, level}; set in settings or inferred by keywords in code; fallback "general health sciences". The NCLEX frameworks / item formats / negative keywords moved out of the shared prompts into the `nclex-rn` exam module. Shared prompts contain no discipline or exam name (tested).
- `lib/accuracy.js` (F1) — residue cleanup (`1×`, "linked to question…", cut "…" tails, truncated cross-references), sentence split + classification, **origin by n-gram overlap with the source** (never asked of the model), analogy box, invented mnemonic/framework stripped (Part A) or boxed (Part B), `honestTitle()`.
- `lib/kb/*` (F2) — schema, BM25 index, lazy per-profile loading (dynamic `import()`, never on the startup path), forbidden-pattern patching with before→after log, reference cards ("not covered in the material", "source says X, reference says Y"), range checks by sex/age stratum in SI or conventional units, scope + jurisdiction checks, `reviewBy` → "may be outdated".
- `scripts/build-kb.mjs` — OFFLINE builder: a fact is dropped unless its quote is found **verbatim** in the cited passage and the source license is verified and open (NC / SA / unverified rejected).
- `lib/solvecheck.js` (B2–B6, B8) — brief parser, logprob confidence (top-1, margin, renormalised over option letters, per-option for multi-select), format/logic checks, CALC recomputation by a tiny parser (no `eval`), DATA read-back with low-probability digit flags, tiers capped by calibration, banner, lesson reconciliation.
- `lib/claims.js` + `proof.js` (F3) — unresolved high-risk claims folded into the existing proof request; verdict cache by claim hash (30 days, 7 for time-sensitive); allowlisted domains only.
- `lib/secondopinion.js` (B7), `lib/evidence.js` (B9, **off by default**), `lib/reports.js` (F4: report error, KB gap list, JSON export), `components/TrustPanel.jsx` (UI), `scripts/calibrate.mjs` (B10), `scripts/kb-sizes.mjs`.
- Solve prompt: profile-templated; `ANSWER` first; `RATIONALE` deleted (net −357 tokens); `DATA` and `CALC` lines added. `parse.js` is unchanged and still works.

### Decisions you may want to reverse
1. **Seed KB facts are `source.verified:false`.** I could not reach the books from the build environment and refused to invent quotes. They *patch* clear errors (the digestive items from review, plus five adult ranges and nursing scope/frameworks) but are shown as "reference — source check pending", never ✓. Run `build-kb.mjs` against real corpora to upgrade them.
2. **No profile is calibrated, so nothing reaches HIGH today.** The brief says an uncalibrated profile is capped at MEDIUM; the consequence is that every AI-solved question currently shows "AI is not fully sure", and `recordAnswer` skips items tagged `unverified` (v3.43.1: `verified` and `pending` are saved). the exam generator is tagged since v3.43.1 (see above).
3. **A model verdict without an allowlisted source is an opinion.** `T` stays ؟; `F` becomes ⚠ "AI check disagrees" with the suggestion on tap, and rewrites text only with an allowlisted source. Grounding for the proof request is **off by default** (`setClaimsGrounding`).
4. **Part B boxes invented mnemonics instead of deleting them** (the AI is the only author there and the prompt asks for a memory tip); Part A strips them.
5. **"Unlabeled = 0" is for sentences the classifier calls high-risk.** Classification is regex heuristics (EN + AR); a claim phrased outside them is not caught.
6. The proof request carries claims only when its text chunk has room; otherwise verification is cut, never the budget.

### Measured (in this build environment, Node 22, mocked network)
- 311 tests pass as of v3.43.1 (238 existing + 43 + 30). Seeded-error suite: 20 cases, every one patched, removed, cleaned or labeled; 0 high-risk sentences left unlabeled.
- Deterministic layer ≈ 4 ms warm on a ~2000-word lesson (p95 under 20 ms; the very first call after load is slower, so `ensureKb` runs a throw-away pass in the background). KB lookup p95 ≪ 10 ms.
- KB bundle: core-digestive 13.3 KB (4.2 KB gzip), core-ranges 2.8 KB, scope-nursing 2.8 KB — lazy chunks (`npm run kb:sizes`).

### NOT tested / unknown — please read
- **Real `logprobs` availability per Gemini model** and whether thinking models return `logprobsResult` for the visible text only. The code asks only for the solve task, probes each model **once** (small free keys included) and remembers the verdict, whether the model refuses (400) or silently omits `logprobsResult`; it never invents probabilities and degrades to code checks + verbalized confidence (capped at MEDIUM). A model that answers with a 400 costs **one** extra request, once per model (refunded in the quota ledger); silent omission costs none.
- **Real grounding** (cost, JSON-mode compatibility, and that grounding links are Google redirects whose *title* carries the site, which is what the allowlist reads).
- **Calibration on real data or real devices.** No golden set exists: ≥300 human-verified, openly licensed items per profile could not be produced here. `tests/golden/questions/_synthetic/` holds two made-up items that only exercise the harness. HIGH-tier error rate is therefore **unmeasured**; never read it as zero.
- **Licenses.** Nothing from OpenStax or any other book is bundled; seed facts are my own paraphrases of standard anatomy/physiology. Every corpus license must be verified per book before `build-kb.mjs` is used (the CC BY vs CC BY-NC-SA listing conflict for *Pharmacology for Nurses* is exactly what `licenseVerified` is for).
- The `nclex-rn` module (formats, `penalizesWrongPicks`, negative keywords) was moved from the old prompt and the brief; it has **not** been checked against NCSBN documents (`checkedAt: null`).
- **Vite build, Android/Electron packaging and the React UI in a browser** were not run (no `node_modules` or network). All JSX parses and the app bundles with esbuild, but TrustPanel / Editor / ExamCard were never rendered.
- (v3.43.0 skipped origin gating for PDF/image sources. Since v3.43.1 they go through the same pipeline; see above.)
- Not implemented: per-profile exam modules other than NCLEX, discipline modules beyond the nursing scope seed, a settings screen for the profile (`setProfile` exists), and the UI button for the second opinion (library + tests only).


## v3.41.0 — تحليل الملفات الصوتية بأقل توكنز (من غير ما الجودة تقل)

**المشكلة الحقيقية**: Gemini بيحسب الصوت **32 توكن لكل ثانية** (دقيقة = 1,920 · ساعة = 115,200) **مهما كانت الصيغة أو البت ريت أو حجم الملف**. يعني ضغط الملف بيوفّر وقت رفع بس، مش توكن واحد. اللي بيكلّف فعلاً هو **مدة التسجيل × عدد الطلبات اللي شايلة الصوت**. والتطبيق بيبعت المصدر مع **كل** طلب في التحليل (كلمات + شرح + ملخص = 3 لـ 5 طلبات) ومع كل رسالة شات. محاضرة 30 دقيقة كصوت = 57,600 توكن × كل طلب.

**الحل**: التسجيل بيتحوّل لنص **مرة واحدة** لما الطالب يضيفه (`lib/audio.js` ← `docs.js → readItem`)، ومن بعدها بيبقى عنصر نص عادي (`label: "AUDIO"`): التحليل والشات والامتحان والدفعات **مبيشوفوش الصوت تاني أبداً**. الكلام كنص أرخص بحوالي 5 لـ 8 مرات (دقيقة ≈ 150 كلمة ≈ 250 توكن بدل 1,920)، وبيتدفع مرة واحدة بدل كل طلب.

**إيه اللي بيحمي الجودة** (مفيش حاجة بتغيّر اللي الموديل بيسمعه):
- الملف بيتبعت **زي ما هو** (من غير إعادة ترميز ولا تسريع ولا قص) — الموديل بيسمع بالظبط اللي الطالب سجّله.
- **طلب واحد** بس، من غير تفكير، ومن غير موديل تاني بيسابقه (`noHedge` في `gemini.js`: السباق كان هيدفع نفس الصوت مرتين).
- موديل Flash القوي الأول (النص هو أساس كل إجابة بعد كده)؛ Flash-Lite بس لو حصة القوي قربت تخلص اليوم.
- نفس التسجيل **مبيتدفعش مرتين**: بصمة الملف (الحجم + هاش أول وآخر 64 ك) ← النص بيتحفظ (آخر 30 تسجيل).
- الملفات الكبيرة بتترفع **مرة** لـ Files API من الملف نفسه (من غير نسخة base64 في الذاكرة)، والصغيرة inline.
- التعليمة قصيرة ومفيهاش توقيتات ولا أسماء متحدثين (توكنز خرج مش هتتستخدم). المصطلحات الطبية والجرعات والأرقام بتتكتب زي ما اتقالت، والعربي يفضل عربي والإنجليزي جوه الكلام يفضل إنجليزي.

**شبكة الأمان** (دي بتتكلم مع Google الحقيقي فلازم متكسرش تحليل):
- Google رفض الصيغة (m4a / webm / amr…) ← الملف بيتفك في المتصفح ويتحوّل 16kHz mono WAV (اللي Gemini بيسمعه أصلاً) ويتبعت مرة تانية. الصيغ اللي Google مش بيسرّدها بتتحوّل على طول من غير طلب مرفوض.
- رابط الملف المرفوع ما اشتغلش (مفتاح تاني / انتهى) ← الطلب بيتكرر مرة (inline لو الملف صغير).
- مفيش كلام (صمت / موسيقى / نبض قلب) ← رسالة صريحة، مش «شرح» فاضي. التطبيق بيفرّغ **الكلام** بس.
- لو الموديل دخل في حلقة (نفس الجملة مرات ومرات) النص بيتنضّف.
- الشاشة بتقول «بيفرّغ الصوت…» وزر التحليل / الإرسال بيستنى لحد ما التفريغ يخلص.

**الحدود بصراحة**: أقصى حجم 150 ميجا (حوالي ساعتين ونص بجودة 128kbps). التحويل الاحتياطي في المتصفح لحد 30 دقيقة / 60 ميجا. الأصوات غير الكلامية (نبض القلب، أصوات الرئة) مش بتتحوّل لنص. الصوت الأصلي **مش بيتخزّن** مع السؤال/المادة، النص بس.

**اتجرّب**: `npm test` = **227 اختبار** (207 القديمة + 20 جديدة في `tests/audio.test.mjs`) بتثبّت: طلب واحد بس بيشيل الصوت، والتحليل الكامل بعده مبيبعتش الصوت أبداً، ومفيش سباق بين موديلين (تجربة ضابطة: من غير `noHedge` الطلب البطيء بيتسابق)، والكاش، والتحويل الاحتياطي، وإن أخطاء المفتاح/الزحمة متتفهمش غلط إنها صيغة.
**ما اتجرّبش**: طلب حقيقي لـ Google بملف صوت حقيقي (مفيش نت في بيئة الشغل) ولا بناء Vite/APK. اختبر على جهازك بتسجيل قصير (MP3 وM4A وواتساب) قبل النشر. فاتفحصت صياغة الملفات اللي اتغيّرت بمترجم TypeScript.

## v3.42 — رفع الصوت أسرع ~4 مرات

**المشكلة:** ملف 23 ميجا خد 160 ثانية رفع (≈ 1.1 ميجابت/ث، سرعة الرفع هي العنق مش جوجل).
**الحل:** `lib/audiopack.js` بيصغّر التسجيل على الموبايل قبل الرفع لـ Opus مونو 16kHz بـ 32kbps (اللي جيميني بيسمعه أصلاً)، فـ 23 ميجا ≈ 5.5 ميجا. بيقص mp3/wav/m4a على حدود الفريمات ويفك كل قطعة ≤ 4 دقايق (ذاكرة محدودة). لو مش ممكن (مفيش WebCodecs، صيغة غريبة، النتيجة مش أصغر بوضوح) أو جوجل رفضت الصيغة → بيترفع الأصلي زي زمان. + نسبة التقدّم الحقيقية أثناء الرفع (XHR) + صبر أطول لمعالجة الملف عند جوجل.
**اتجرّب:** `npm test` = **238 اختبار**؛ الـ Ogg/mp3/wav/m4a اتفحصوا بـ ffmpeg على ملفات حقيقية. **ما اتجرّبش** على موبايل حقيقي ولا على جوجل الحقيقي (WebCodecs وقبول جيميني لـ ogg/opus). لو جيميني رفض الصيغة التطبيق بيرجع للأصلي لوحده.

## v3.40.10 — توفير توكنز: شيل «نص السؤال» + الترجمة والنطق جوجل بس

**1) خانة «نص السؤال» اتشالت خالص** — السؤال أصلاً موجود في مرفق الطالب (الصورة أو الملف)، فإعادة كتابته كانت بتصرف **طلب كامل لـ Gemini + توكنز الرد** من غير فايدة.
- تحليل السؤال بقى مرحلتين بس: **الكلمات** و**الشرح + التريكات**. (على المفتاح المجاني: **4 طلبات بدل 5**، وعلى المفتاح الكبير **5 بدل 6**.) `lib/config.js → tasksFor(kind)` هو اللي بيحدد المراحل: السؤال = `reason` + `words`، والشرح (المادة) لسه بيشغّل مرحلة الملخص الخلفية زي ما كانت لأنها بتغذّي العنوان والشات والمكتبة.
- العنوان التلقائي ومعاينة السطر الواحد في الرئيسية وشاشة الموضوع بقوا بيتاخدوا من **أول جملة في الشرح** (من غير أي طلب إضافي) عن طريق `bodyLine/snippetOf` في `lib/text.js`. الأسئلة القديمة المحفوظة لسه محتفظة بنصها وبتعرضه في المعاينة والبحث والشات.
- شريط التقدّم (`createTracker`) ورفع الأسئلة المتعددة (`batch.js`) بقوا بيتابعوا المراحل اللي بتشتغل فعلاً، فمفيش شريط بيفضل واقف على مرحلة مش هتيجي.

**2) ترجمة الكلمات والجمل = Google بس، من غير Gemini** — اتشال «الملاذ الأخير» اللي كان بيبعت طلب Gemini لو كل المزوّدين المجانيين فشلوا (`lib/wordtr.js`). لو Google وقف، الطالب بياخد رسالة «خدمات الترجمة مش بترد دلوقتي» بدل ما يُصرف توكنز. (المزوّد الاحتياطي MyMemory لسه موجود: مجاني وبدون مفتاح، وتقدر تحذفه من `PROVIDERS` لو عايز Google لوحده.)

**3) النطق = Google الأمريكي السريع بس** — اتشال صوت Gemini (الرجالي) بالكامل من `lib/speech.js` وزرّ اختياره من الإعدادات. التطبيق بيلعب من الكاش أولاً، وبعدين صوت Google `en-US`، وبعدين صوت التليفون **لو كان en-US حقيقي** (مش أي لكنة تانية). مفيش أي طلب لـ Gemini للنطق أبداً.

**اتجرّب**: `npm test` = **207 اختبار** كلها بتعدّي (200 القديمة اتحدّثت لتطابق السلوك الجديد + 7 جديدة في `tests/google-only.test.mjs` بتثبّت: مفيش مرحلة OCR للسؤال، الترجمة مبتبعتش لـ Gemini حتى لو Google فشل، والنطق مفيهوش Gemini).
**ما اتجرّبش**: بناء Vite/APK (مفيش `node_modules` ولا نت في بيئة الشغل)، فاتفحصت صياغة كل ملفات `src` بمترجم TypeScript بس. شغّل `npm run build` عندك قبل النشر.

## v3.39 — نافذة المفتاح أبسط لغير التقني
- النافذة بقت خطوتين: «هات مفتاح مجاني» (برابط مباشر) ثم «الصقه هنا»، مع سطر حالة واضح فوق (✅ شغّال / 👋 محتاج مفتاح).
- اتشال زرّا «جودة أولاً» و«سرعة قصوى»: التطبيق بيختار لوحده دايماً. اللي كان مختار واحد منهم اتنقل لـ«تلقائي» مرة واحدة.
- الإعدادات التقنية (الإجابات المحفوظة · تقسيم الردود · مصادر الصور) اتنقلت جوه «إعدادات متقدمة» مقفولة.
- اتصلّح الشريط الأفقي اللي كان بيظهر في النافذة.

## v3.38 — حل جذري لمشكلة "مش قادر أتعرف على نوع المفتاح"
- مفاتيح Google الجديدة بتبدأ بـ `AQ.` (مش `AIza`) — اتضاف التعرّف عليها.
- الحل الجذري: لو المفتاح شكله مش معروف، التطبيق بقى يسأل كل شركة بالدور (Google ← Mistral ← OpenAI ← Groq ← OpenRouter ← Claude) والشركة اللي تقبله هي صاحبته. يعني أي صيغة مفاتيح جديدة في المستقبل هتشتغل من غير تحديث للتطبيق.
- رسالة الخطأ بقت تفرّق بين "مفتاح مرفوض" و"مفيش نت".

## v3.37 — حل جذري لـ 4 مشاكل عامة (تسريب البرومبت · الإملاء · تداخل اللغات · بطء التجربة)

**1) تسرب البرومبت** — `src/lib/guard.js` بيتفعّل جوه `runTask()` (الباب الوحيد لكل ردود الموديلات)، فبيغطي كل الشاشات من غير قائمة لكل برومبت. بيقارن كل سطر في الرد بالتعليمات اللي اتبعتت فعلاً للموديل في نفس الطلب (نوافذ من 5 كلمات)، وبيشيل السطر لو أغلبه تعليمات، وبيشيل كمان صيغ ثابتة زي `(at most 10)` و`One bullet per …`. السطر اللي لسه بيتكتب وباين إنه تعليمة بيتخبّى وهو بيتكتب (مش بيظهر ويختفي). علامات `===EXPLANATION===` ونص الطالب نفسه عمرهم ما بيتلمسوا. بيشتغل بس على مهام الشرح العربي (`lesson:*` ما عدا `diagram/chatplan` + `words` + `word:tr`)؛ OCR وJSON وSVG بتفضل زي ما الموديل كتبها.

**2) الأخطاء الإملائية** — نفس الحارس بيصلّح تلقائياً الأخطاء الهيكلية اللي صح في أي كلمة عربية: حرف مكرر 3 مرات، حروف مبتتتكررش (مثلا `ةة` و`ىى`)، `ة` أو `ى` في نص الكلمة، + جدول `SPELL_FIXES` للكلمات اللي اتشافت غلط (فيه `وواكامل → ومتكامل`؛ ضيف سطر لما تلاقي كلمة جديدة). لو الرد جه من موديل ضعيف (Flash-Lite أو محرك إضافي) واحتاج **2 إصلاحات أو أكتر** بيتكتب تاني **مرة واحدة** بموديل أقوى (حد أقصى 4 مرات كل 10 دقايق عشان الحصة المجانية). وكمان `ARABIC_RULE` بقى فيه جملة إملاء وجملة "ما تكررش التعليمات".
> مهم: ده مش مدقق إملائي بقاموس. الكلمة المتغيّرة بالكامل (زي لو الموديل اخترع كلمة من حروف سليمة) مش هتتعرف إلا لو دخلت جدول `SPELL_FIXES` أو اتكررت كفاية للمراجعة.

**3) تداخل اللغات** — (أ) علامات الترقيم اللي بتقفل جملة إنجليزي (`Heparin,` `Warfarin.`) بقت خارج الجزيرة الإنجليزية وبتفضل مع الجملة العربية (كانت بتتحط على الجنب الغلط). (ب) اتجاه السطر بقى بالأغلبية: جملة عربي فيها مصطلحات إنجليزي = RTL، وجملة إنجليزي فيها كلمة عربي واحدة = LTR (`dirFor`). (ج) مكوّن `<Mixed>` لنصوص قصيرة (ملخص موضوع، أضعف نقطة).

**4) تجربة التعديلات من غير ما تنزّل 160 ميجا** —
- `deploy-web.yml`: كل push بيبني نسخة الويب وينشرها على GitHub Pages في حوالي دقيقة. افتح الرابط على الموبايل (أو ثبّته كـ PWA) وهتلاقي آخر نسخة. **النسخة دي من غير أي مفاتيح** (صفحة عامة؛ دخّل مفتاحك مرة واحدة من 🔑 جوه التطبيق). إعداد مرة واحدة: Settings → Pages → Source = GitHub Actions.
- `build-apk-live.yml` (تشغّله مرة بإيدك): APK صغير بيفتح آخر نسخة من Pages. تثبّته مرة واحدة وبعدها أي push يبان لما تفتح التطبيق.
- **الكمبيوتر (الـ160 ميجا هي نسخة Windows/Electron، لأنها بتحزّم Chromium معاها):** أسهل حل تفتح رابط Pages في Chrome/Edge وتعمله Install (من غير تنزيل). أو شغّل `build-desktop.yml` يدوي وحط في خانة `live_url` عنوان Pages، فتطلع نسخة ويندوز بتفتح آخر نسخة ويب تلقائياً (تثبّتها مرة واحدة)، ولو مفيش نت بتفتح النسخة اللي جواها. تنبيه: بيانات التطبيق (الأسئلة والمفاتيح) بتتحفظ لكل عنوان لوحده، فالنسخة الحية بتبدأ فاضية ومحتاجة نسخ احتياطي من شاشة النسخ الاحتياطي.
- `build-apk.yml` و`build-desktop.yml` بطّلوا يشتغلوا مع كل push؛ بيشتغلوا يدوي أو لما يتغير حاجة native (أيقونات، plugins، `capacitor.config.json`، `electron/`). ومعاهم cache لـ npm وGradle وخطوة تطبع أكبر ملفات جوه الـ APK (عشان نعرف إيه اللي مكبّر الحجم).
- `public/sw.js`: service worker بيجيب آخر نسخة من النت الأول ويفتح أوفلاين من آخر نسخة اتحمّلت.

## v3.33 — حل جذري للمفتاح المجاني (من غير فلوس، ومن غير محركات إضافية، ومن غير ما الطالب يعمل حاجة)

**التشخيص** (من أرقام Google المنشورة وأخطاء حقيقية اتبلّغ عنها): المفتاح المجاني مش «بطيء»، هو **صغير**، والتطبيق ما كانش فاهم ده.
- موديلات Flash (3.6 و3.8) في الطبقة المجانية ليها حوالي **5 طلبات في الدقيقة و20 طلب في اليوم**، وFlash-Lite حوالي 10 في الدقيقة و500 في اليوم. Google مبقتش تنشر الأرقام (بتظهر في AI Studio بس)، فالتطبيق **بيتعلمها من المفتاح نفسه**.
- التحليل الواحد كان بيبعت **6 طلبات** للموديل القوي، يعني 3 تحليلات بس في اليوم وحصة اليوم تخلص.
- لما حصة اليوم تخلص، رد Google **مش بيقول «per day»** وبيقول «retry in 20s». النوع الحقيقي مكتوب بس في `details[].violations[].quotaId`. والتطبيق كان بيخمّن من نص الرسالة، فكان بيعامل «خلصت النهارده» كأنها «زحمة 20 ثانية»: تبريد، إعادة، 429 تاني، انتظار… **طول اليوم، لكل طلب في كل ميزة** (تحليل ودردشة وصور)، وبينزل لموديل Lite من غير ما يقول.
- كل أزمنة الانتظار كانت أرقام ثابتة مكتوبة لمفتاح تاني: مهلة أول رد 60–240 ث، وتحوّط بعد 15–30 ث.

**اللي اتغيّر** (مفيش برومبت ولا موديل ولا شكل رد اتغيّر):
1. **`lib/quota.js`** (جديد): بيقرا خطأ الحصة المنظَّم (يوم / دقيقة / توكنات / صفر)، وبيحتفظ لكل موديل (وبيفضل بعد قفل التطبيق) بعدد الطلبات النهارده وفي آخر دقيقة، والحدود اللي اتعلمها، و«خلص لحد التجديد» (منتصف الليل بتوقيت المحيط الهادي = الساعة 10 الصبح بالقاهرة)، وإن `gemini-flash-latest` و`gemini-3.8-flash` **نفس الحصة**.
2. **المحرك بقى بيعرف الحصة قبل ما يصطدم بيها**: موديل خلصت حصته مبيتبعتلوش حاجة لحد التجديد (حتى بعد إعادة تشغيل وتحديث قايمة الموديلات)، وموديل وصل لجدار الدقيقة بيستنى الوقت المظبوط، ولو كل الموديلات خلصت الرسالة بتقول الحقيقة ووقت التجديد (بدل «استنى دقيقة»).
3. **التحليل بقى 5 طلبات بدل 6**: الشرح الرئيسي والتريكات بيتكتبوا في طلب واحد بنفس الـ prompt الكامل ونفس الـ brief المتحقَّق منه. ده افتراضي على أي مفتاح ما اتأكدش إنه كبير (مفتاح مدفوع بيتعرف من حد كبير اتعلمه أو من `VITE_PAID`). وقايمة الكلمات بتروح Flash-Lite لما حصة Flash تقارب الخلاص عشان الباقي يتحفظ للدرس نفسه.
4. **أزمنة بتتعلم من المفتاح**: وسيط زمن أول رد لكل موديل ولكل نوع مهمة (آخر 12 رد، محفوظ). الطلب الساكت بيتحوّط عند 3 أضعاف المعتاد (بحد أدنى 5 ث) وبيتقطع عند 8 أضعافه (بحد أدنى 20 ث)، بدل 15–30 ث و60–240 ث. وقبل ما فيه قياس، الأرقام القديمة زي ما هي.
5. **شفافية**: سطر ⏳ تحت النتيجة بيقول أنهي موديلات خلصت حصتها ومتى بترجع، وسطر 🔎 (من v3.32) بيفسّر الوقت.
6. إصلاحات: الانتقال للموديل التالي جوه نفس السباق مبقاش بيستدعي مسار اتحط على جنب في نفس اللحظة، وتحديث قايمة الموديلات مبقاش بيمسح «خلصت النهارده».

**القياس** (محاكاة لـ Google بحدودها الحقيقية: `npm run sim:free`، بزمن افتراضي، نفس اليوم على المحرك القديم 3.31 والجديد):

| السيناريو | القديم | الجديد |
|---|---|---|
| 12 سؤال في ليلة بحصص مجانية: تحليلات كاملة بالموديل القوي | 4 | **8** |
| نفس السيناريو: محاولات فاشلة | 71 | **7** |
| نفس السيناريو: زمن التحليل | 35 ث | 35 ث |
| 25% من طلبات Flash بتفضل ~100 ث في طابور Google (6 بذور): متوسط التحليل | 51 ث | 46 ث |
| نفس السيناريو: أسوأ تحليل | 93 ث | 81 ث |
| نفس السيناريو: محاولات فاشلة / طلبات نزلت لـ Lite | 40 / 17 | **6 / 9** |

**حدود الأرقام دي بصراحة**: دي نموذج لـ Google مبني على حدود منشورة وأخطاء اتبلّغ عنها، مش قياس على Google نفسها. ومحاكاتي **ما طلّعتش 409 ثانية**: المكسب الأكبر في الجودة (تحليلات أكتر بالموديل القوي بدل النزول لـ Lite بصمت) وفي إلغاء الهدر، أما الوقت نفسه فتحسّنه متواضع (حوالي 10%) لأن تكلفة اكتشاف الطلب الساكت لازم تتدفع. الـ 409 ثانية عندك لسه محتاجة سطر 🔎 لتتفسّر: لو ظهر «ضاع Xث في timeout» يبقى طابور Google، ولو ظهر «تفكير» يبقى الموديل بيفكّر كتير.
**ما فيش حل بيخلق حصة من العدم**: 20 طلب قوي في اليوم لكل موديل ده سقف Google. اللي اتعمل إنه بيتصرف فيهم صح، وبعد ما يخلصوا الشغل بيكمّل على Lite **ومكتوب على الشاشة**.
**بوابة v3.32** (`gateway/`) لسه موجودة لكن **اختيارية ومعطّلة** (للي يقرر يوم يدفع). مش محتاجها هنا.

## v3.32 — حل جذري لبطء الـ AI (التحليل · الدردشة · الصور · الـ AI العام)

**التشخيص**: كل ميزات الـ AI بتعدّي على نقطة واحدة (`lib/gemini.js`) وبتتكلم مع Google بمفتاح **مجاني** (ومدمج في الـ APK). الطبقة المجانية ليها أقل أولوية وحصص صغيرة، فالطلب بيقعد في طابور Google **ساكت** دقيقة أو أكتر، أو يرجع 429/503. والتطبيق كان مظبوط على الصبر: مهلة أول رد 120–240 ث، وكل موديل رسم صور بياخد لحد 170 ث ورا بعض. فالانتظار الضايع (مش الكتابة ولا التفكير) هو اللي بيوصّل التحليل لـ 409 ث. وإصدارات v3.23 → v3.27 كانت التفافات حوالين نفس السبب، ومفيش كود في التطبيق يقدر يدّي مفتاح مجاني أولوية مدفوعة.

**الحل** (من غير محركات إضافية، ومن غير ما الطالب يكتب أي حاجة):

1. **`gateway/`** — بوابة صغيرة (Cloudflare Worker) بتشيل مفتاح Google **المدفوع** بدل التطبيق، والرد بيعدّي منها كلمة كلمة. التطبيق بيشتغل بـ «رمز دخول» بدل مفتاح، ونافذة 🔑 بتبقى «الـ AI شغّال تلقائياً» (من غير حقل مفتاح ولا لوحة محركات إضافية). الدليل الكامل: `gateway/README.md`. نشرها بزرار من GitHub Actions: **Deploy AI gateway**.
2. **ملف شبكة مدفوع** (`lib/config.js` → `NET`، بيشتغل لما `VITE_GATEWAY_URL` أو `VITE_PAID=1`): الطلب الساكت بيتقطع بعد 60 ث بدل 120–240 (موديل Pro بتفكير عالي: 120 ث)، والتحوّط للموديل التاني بيبدأ بعد نص الوقت، وانتظار الموديلات النايمة 15 ث بدل 40، ورسم الصور بيقف بعد موديلين صامتين بدل ما يلف على القايمة كلها. **الملف المجاني (البناء العادي) متغيّرش**، ومثبّت باختبار.
3. **تفسير الوقت** (`lib/latency.js`): كل طلب بيسيب أثر، وتحت نتيجة التحليل بيظهر سطر 🔎 بيقول بالظبط: كام ثانية **ضاعت في محاولات فاشلة وانتظار** (مع السبب: `503×2 · timeout`)، وكام **انتظار أول رد**، وكام **تفكير** (≈ تقدير من عدد توكنات التفكير اللي بتبلّغ عنها Google)، وكام **كتابة** (بالتوكن والسرعة). كده أي بطء بعد كده يتشخّص بدل ما يتخمّن.
4. **الدردشة**: البحث في Google بيزوّد ثواني قبل أول كلمة، فاتشال **بس** من الرسائل اللي مش محتاجة معلومة جديدة (ترجم · بسّط · لخّص · شكراً…، قصيرة وبدون أرقام). أي سؤال تاني **بيبحث زي ما كان** (`needsSearch` في `lib/chat.js`، متغطّي باختبار). مفتاح البحث اللي في الواجهة لسه بيتحكم فيه.
5. **الحد اليومي لكل جهاز** على الـ gateway (اختياري)، و`VITE_SERVICE_TIER=priority` لأولوية Google (Tier 2+، لو اترفضت بيتشال لوحده).

**البناء**: `build-apk.yml` و`build-desktop.yml` بيقروا `GATEWAY_URL` (Variable) و`GATEWAY_TOKEN` (Secret)، وبيفضّوا مفاتيح Gemini/Groq/OpenRouter/Mistral من الملف لما الـ gateway يشتغل.

**اتجرّب**: `npm test` = **101 اختبار** (60 الأصلية + 41 جديدة) كلها بتعدّي، و`vite build` حقيقي (عادي ومعاه متغيّرات الـ gateway). `tests/loader.mjs` اتزوّد ببديل `react` لبيئة الاختبار بس، لأن `mistakes.test.mjs` كان بيقع قبل كده في أي تسطيب جديد (Node مبيشوفش `useSyncExternalStore` من حزمة react).
**واتجرّب الـ gateway على محرك Cloudflare الحقيقي (workerd عبر wrangler محلياً)** مع Google مزيّف: البث وصل على دفعات من غير buffering، وgzip بعربي سليم، والمفتاح مبيوصلش للجهاز.
**ما اتجرّبش**: النشر على حسابك، والاتصال بـ Google الحقيقي (الشبكة اللي اتبنى فيها مقيّدة). فالفرق الحقيقي في السرعة لازم يتقاس عندك، وسطر 🔎 هو الأداة.

## v3.31 — غلطاتي + إصلاح النسخ الاحتياطي

**1 · غلطاتي** (أيقونة 📕 في الشريط العلوي + كارت في الرئيسية + زر «افتح غلطاتي» في نتيجة الامتحان):
- أي سؤال تجاوبه غلط في الامتحانات داخل التطبيق بيتحفظ لوحده (`lib/mistakes.js`، مفتاح `clinix:mistakes`). نفس السؤال لو اتغلط فيه تاني بيزوّد العدّاد ومش بيتكرر.
- مترتّب: **مجال** (القلب، التنفسي، الأدوية…) ← **موضوع** ← سؤال، مع بحث وفلتر وطيّ/فتح. كل سؤال بيوضّح إجابتك والصح والتعليل.
- **تدريب** على كل الغلطات أو على موضوع (الاختيارات بتتبدّل): إجابتين صح ورا بعض = «اتقنتها»، والغلط بيرجّعها للمراجعة. زر «اشرحلي» و«امتحان جديد على الموضوع» بيستخدموا الـ AI.
- داخل النسخة الاحتياطية، ومتدمج في الاسترجاع.

**2 · النسخة الاحتياطية**: السبب إن التحميل برابط blob مش بيشتغل في WebView الأندرويد (الزر ما كانش بيعمل حاجة). دلوقتي: أندرويد → Filesystem + Share (قايمة المشاركة تحفظ في Drive/الملفات)، متصفح موبايل → Web Share، كمبيوتر → تنزيل. الرسائل صادقة (إلغاء المشاركة مش «اتحفظ»). النسخة بقت تشمل غلطاتي ومعرض الصور، والاسترجاع بيدمج المواضيع (كانت بتتجاهل). ⚠️ لازم `npm install` (إضافات `@capacitor/filesystem` و`@capacitor/share`) وبناء APK جديد.

## v3.30 — الشعار الجديد

- أيقونة التطبيق (`assets/icon-only.png` + `icon-foreground.png` + `icon-background.png`) وشاشة البداية (`resources/splash_icon.png`) وأيقونة سطح المكتب بقت بالشعار الجديد (الشعار + كلمة ClinixStudy، من غير السطور الصغيرة تحتها).
- الشعار في الشريط العلوي (`Brand` في `components/ui.jsx`) بقى الشعار الجديد، والاسم Clinix/Study بلونين.
- خلفية شاشة البداية بقت **أبيض** (`#FFFFFF`) بدل التيل، لأن الشعار كحلي وتيل؛ اتغيّرت في `capacitor.config.json` و`index.html` و`electron/main.cjs` وخطوة `Launch splash` في الـ workflow.
- صور الأيقونة الكبيرة (4096) للمصدر بس؛ أندرويد بيولّد منها المقاسات الصغيرة وقت البناء، فمفيش تأثير على سرعة التطبيق. اللي بيتحمّل مع التطبيق (شعار الشريط العلوي وشعار شاشة المتصفح) صور WebP خفيفة (17KB و70KB).
- أيقونة المتصفح (`public/favicon.png`) وشعار شاشة البداية في المتصفح (`public/logo-full.webp`).

## النسخة الكاملة v3.27 (v3.19 + باتش 3.20 + المعرض 3.21 + تحسينات 3.22 → 3.26 + ClinixStudy 3.27)

- دي نسخة **كاملة** جاهزة للرفع على مستودع جديد: ارفع **محتويات** الفولدر (مش الفولدر نفسه).
- ⚠️ **`package.json` كان فاضي (0 بايت) في ملف v3.19** اللي اتبعت، فاتعمل من جديد من الاستيرادات الفعلية في الكود وملفات الـ workflows: Vite 5 + React 18، و**Capacitor 6** (عشان Java 17 اللي في الـ workflow؛ Capacitor 7 بيحتاج Java 21)، و Electron 33 + electron-builder (ملفين: `ClinixStudy-Setup-*.exe` و`ClinixStudy-Portable-*.exe` جوه `release/`). لو عندك `package.json` شغّال من نسخة أقدم، قارنه بيه قبل ما تستبدله.
- مفيش `package-lock.json`، فـ `npm install` هيحدد أحدث نسخ داخل نفس الإصدار الرئيسي.

## v3.27 — ClinixStudy + مستوى الرد في الشات + فلتر الكلمات

**1 · مستوى الرد في دردشة الـ AI** (`lib/chat.js` → `REPLY_LEVELS` / `replyPlan`، و`components/ChatPanel.jsx`):
فوق صندوق الكتابة اختيار من 4 مستويات، بيتفتكر، وبيتطبّق على الرسالة الجاية. المستوى بيحدد **أنهي موديل يرد** و**قد إيه يفكّر**:

| المستوى | الموديل | التفكير | الوقت المتوقع |
|---|---|---|---|
| سريع | الموديل الصغير السريع (lite) | شبه معدوم + رد قصير | ثواني |
| متوازن (الافتراضي) | موديل Flash اليومي | يتظبط حسب السؤال (زي v3.26) | حوالي 10 ثواني |
| عميق | موديل Pro القوي | medium | حوالي 30 ثانية |
| أقصى دقة | موديل Pro القوي | high (أعمق تفكير) + مراجعة ذاتية | من دقيقة لدقيقتين |

- تحت الاختيار سطر بسيط بيشرح المستوى المحدد، وبيوضح إن **كل ما زاد المستوى زادت الدقة وزاد وقت الانتظار**، ونقط صغيرة على كل زرار بتبيّن الجهد.
- المستويان «عميق» و«أقصى دقة» بيجاوبوا من Gemini Pro بس (من غير ما محرك إضافي صغير يسبقه)، ومفيش «تحوّط» بعد 4 ثواني لأن الموديل بيفكّر. لو حصة Pro خلصت أو Pro مشغول، الطلب بيكمل أوتوماتيك على موديلات Flash.
- مفيش تغيير في الرسم والامتحانات (دول ليهم محركاتهم)، وطلبات «بالتفصيل» الكبيرة بتفضل بتتكتب بالتوازي في كل المستويات ما عدا «أقصى دقة» (إجابة واحدة بتركيز كامل).
- اختبارات جديدة في `tests/chat.test.mjs`.

**2 · الاسم الجديد ClinixStudy:**
- اتغيّر في: واجهة التطبيق (الشعار)، `index.html`، اسم الأندرويد (`capacitor.config.json`)، نافذة سطح المكتب (`electron/main.cjs`)، `package.json` (الاسم، `productName`، أسماء ملفات التثبيت)، الـ workflows (أسماء الملفات الناتجة)، والـ README، وأيقونات التطبيق (`assets/` + `resources/splash_icon.png`) اتعاد رسمها بالاسم الجديد.
- معرّفات التطبيق اتغيّرت: `com.clinixstudy.app` (أندرويد) و`com.clinixstudy.desktop` (ويندوز). ⚠️ ده معناه إن الأندرويد والويندوز هيعتبروه **تطبيق جديد** بجانب القديم، ومحتوى القديم (أسئلتك وشروحاتك) **مش بينتقل لوحده بين التطبيقين**. قبل ما تنزّل الجديد: من التطبيق القديم اعمل **نسخة احتياطية** (النسخة الاحتياطية)، وبعد التثبيت استرجعها في الجديد. الاسترجاع بيقبل النسخ القديمة (`app: "nclex-rn"`) ويحوّل مفاتيحها للاسم الجديد.
- لو فتحت النسخة الجديدة **على نفس الرابط/نفس التطبيق** (متصفح، أو بناء بدل القديم بنفس الـappId)، بياناتك بتتنقل أوتوماتيك مرة واحدة: قاعدة البيانات `nclex-rn` → `clinix-study`، ومفاتيح الإعدادات `nclex:*` → `clinix:*` (`lib/legacy.js` و`lib/storage.js`). القديم بيفضل زي ما هو من غير حذف.
- كلمة «NCLEX-RN» جوه تعليمات الذكاء الاصطناعي (مثلاً «بيذاكر لامتحان NCLEX-RN») فضلت زي ما هي لأنها اسم **الامتحان** مش اسم التطبيق.
- ملف الـ workflow بيدوّر على `package.json` باسم `clinixstudy`.

**3 · الكلمات السهلة اللي كانت بتظهر في «كلمات جديدة»** (`lib/parse.js` + `lib/b1words.js` + `lib/prompts.js`):
السبب الفعلي مش الـAI بس: الفلتر المحلي كان بيعتمد على قاموس ناقص، وأي كلمة مش فيه كانت بتعدّي حتى لو الـAI وصفها [B2]. اتصلح كده:
- قاموس جديد `b1words.js` بكلمات A2–B1 الشائعة (temperature, pressure, symptom, treatment, recommend, schedule, review …) وكلمات الجسم والصحة اللي أي طالب تمريض يعرفها.
- العبارات المكوّنة من كلمات سهلة مش بتعدّي إلا لو **عبارة فعلية حقيقية** (rule out, cut back on, deal with) أو جملة امتحان ثابتة (requires further teaching). مثال: take care / go to bed / pick up بتتشال.
- وسم [MED] مش بيحمي كلمة أو كلمتين سهلتين (fever, pain, blood pressure, chest pain).
- تعليمات الـAI اتشدّدت بأمثلة الكلمات اللي كانت بتتسرّب.
- اختبارات جديدة في `tests/words.test.mjs` (بتتأكد إن الكلمات السهلة بتتشال وإن كلمات B2+ والمصطلحات الطبية والاختصارات بتفضل).
- التغيير بيشتغل على التحليلات **الجديدة**. الأسئلة المحفوظة قبل كده ليها قوايم قديمة: افتح السؤال واضغط «جرّب الجزء ده تاني» على كلمات جديدة لو عايز تنضّفها.

**4 · رد الـ AI الطويل (خصوصاً «لخّص اللي ذاكرته») بقى أسرع بنفس الجودة** (`lib/chatflow.js` + `lib/chat.js` + `lib/library.js`):
- **السبب الحقيقي:** طلبات زي «لخص ما ذاكرت» ما كانتش بتتعرّف كطلب كبير، فكانت بتتكتب كلها كرد **واحد** طويل كلمة ورا كلمة بدل ما تتقسّم. دلوقتي بتتعرّف (`isLibraryAsk`) وبتتكتب على **حد أقصى 4 أقسام في نفس اللحظة**.
- أقسام الملخص هي **مواضيعك أنت** (`localOutline`): من غير طلب «تخطيط» منفصل (كان بيضيف عدة ثواني قبل أول كلمة)، وكل كاتب بيشوف **النص الكامل** للأسئلة والشروحات اللي في قسمه (قبل كده كان بيشوف فهرس العناوين بس)، فالملخص من مادتك فعلاً.
- باقي الطلبات الكبيرة اللي محتاجة تخطيط: طلب الخطة بيروح للموديل الأصغر والأسرع الأول.
- نفس تعليمات الجودة ونفس العمق لكل قسم، ومفيش تقليل في الطول أو التفكير.
- ⚠️ بالأمانة: الطلب الكبير بقى ياخد 4 طلبات في نفس اللحظة بدل طلب واحد، فهيستهلك من حصة Google المجانية أسرع. لو حصلت زحمة بيكمل على موديلات تانية لوحده.

**4-ب · كل قسم يظهر أول ما يخلص** (`compose` في `lib/chatflow.js`): قبل كده القسم التاني كان مستني الأول يخلص، فالرد كان بيظهر على دفعات. دلوقتي أي قسم بيظهر فوراً وبيتكتب قدامك لايف. الأقسام اللي لسه ما بدأتش بتحجز مكانها بعنوانها وسطر «⏳ بيتكتب دلوقتي…» علشان الترتيب ما يتغيّرش ومفيش حاجة بتقفز لما تتملي. كارت الانتظار بيفضل تحت الرد لحد ما آخر قسم يخلص. لو وقّفت الرد في النص، الأقسام المكتوبة بتفضل والأماكن المحجوزة بتتشال.

**5 · وقت انتظار أكتر إبهاجاً** (`lib/waiting.js` + `components/WaitCard.jsx`): بدل النقط التلاتة، كارت بيوضّح بالظبط الشغل الجاري («بنقسّم الرد لأقسام» ثم «بنكتب 4 أقسام في نفس اللحظة · خلّص 2 من 4»)، وعدّاد، وشريط تقدّم بيقرّب من 94٪ ومش بيوقف على 100٪ علشان ما يبانش واقف، ونقط للأقسام اللي خلصت، ومعلومة صغيرة تتغيّر كل 7 ثواني (نصيحة NCLEX، أو كلمة B2+ بمعناها، أو جملة تشجيع)، وبعد 15 و40 و80 ثانية رسالة طمأنة. بيظهر في الرد النصي والرسم والامتحان.

**6 · البحث قبل الرد + مصادر تحت كل رد** (`lib/gemini.js` → `search`، `lib/chat.js`، `lib/sources.js`، `components/Sources.jsx`):
- كل رد في دردشة الـ AI (الرئيسية وبتاعة السؤال والدرس) بيتبعت لـ Gemini ومعاه **Google Search** (`tools: [{ google_search: {} }]`)، والتعليمات بتقول له يبحث الأول عن أي معلومة طبية أو دوا أو قيمة معملية أو قاعدة NCLEX ويكتب من اللي لقاه، ويقول بصراحة لو النتايج متضاربة أو مفيش مصدر موثوق بدل ما يخمّن. المعلومات اللي جاية من أسئلتك المحفوظة بتتاخد زي ما هي.
- تحت الرد قايمة **🔗 المصادر** مرتبة ومرقّمة، كل مصدر رابط بيتفتح في المتصفح، وسطر صغير بالحاجات اللي اتبحث عنها. المصادر المتكررة بتتدمج، وبتتجمّع من كل الأقسام لو الرد كبير. بتتحفظ مع الرسالة.
- لو الرد الطويل اتكتب من غير أي مصدر (موديل رفض أداة البحث، أو محرك احتياطي)، بيظهر تنبيه صريح «الرد ده اتكتب من غير مصادر بحث، راجع المعلومات المهمة».
- الرد اللي لازم يطلع بمصادر ما بيبدأش على محرك إضافي صغير: الشات بيشتغل على Gemini أولاً.
- زرار صغير فوق صندوق الكتابة بيقفل/يفتح البحث (الافتراضي شغّال) لو حصة Google المجانية خلصت أو عايز رد أسرع.
- كارت الانتظار بيقول «بنبحث ونراجع المصادر» في أول ثواني.
- اختبارات جديدة (`tests/chat.test.mjs`).
- ⚠️ التكلفة: البحث بيضيف عدة ثواني قبل أول كلمة، وبيستهلك من حصة Google المجانية (الرد الكبير فيه كذا كاتب بيبحثوا). التغيير ده خاص بالدردشة؛ شرح الأسئلة والتحليل التلقائي والامتحانات لسه من غير بحث.

**7 · تسريع إضافي للدردشة بعد إضافة البحث** (`lib/chat.js`، `lib/router.js`، `components/ChatPanel.jsx`):
- **ملخص مكتبتك ما بيبحثش على النت**: «لخص ما ذاكرت» ملخص لمادتك أنت (الكتّاب شايفين نصوصها كاملة وبيستشهدوا بأكوادها)، فالبحث كان بيضيف انتظار من غير معلومة تتراجع. أي سؤال تاني لسه بيبحث ويطلع بمصادر.
- **بحث في جولة واحدة**: التعليمات بتطلب من الموديل يبحث مرة واحدة (كذا استعلام مع بعض) ويجاوب، من غير ما يكرر البحث.
- **تحوّط أبكر للطلب العالق**: الطلب اللي بيبحث قبل ما يرد بقى له فئة تحوّط خاصة (9–16 ثانية) بدل 15–30: لو المحرك واقف، محرك تاني بيشتغل بدري.
- **مهلة أول بايت 45 ثانية** بدل 90 (و30 للسريع): طلب ساكت 45 ثانية يبقى عالق مش بطيء، والمحرك التاني بياخد مكانه أسرع.
- **الشاشة بتتحدّث كل 60 ملي ثانية كحد أقصى** وقت كتابة الرد (كانت بتتحدّث مع كل حزمة من النت، وبـ4 أقسام مع بعض ده تقيل). النص الأخير بيتعرض فوراً.
- اختبار جديد في `tests/chat.test.mjs`.

## v3.26 — «المحرك الذكي»: رد أسرع + مفيش انتظار لما Google تزحم (مجاني 100%)

**المشكلة الحقيقية:** حصة Gemini المجانية مش حصة واحدة، دي حصص صغيرة كتير: **كل موديل له حصته (طلبات/دقيقة وطلبات/يوم)**، والحد **على المشروع مش على المفتاح** (مفتاح تاني في نفس المشروع ما بيزودش حاجة). التطبيق كان بيحط كل طلبات التحليل على موديل واحد، فبيخبط في حده، وبعدين يستنى 2 ثانية ثم 4 ثم 8 ويفشل، والموديلات التانية فاضية.

**1 · مسارات (Lanes) بدل الانتظار** (`lib/router.js` + `lib/gemini.js`):
- أول ما موديل يرد 429 أو 503 بيتحط «ينام» (بمدة Google نفسها لو قالتها) والطلب **يروح للموديل اللي بعده في نفس اللحظة**.
- الموديلات المتساوية في الجودة (مثلاً 3.8-flash و3.6-flash) بيتوزع عليها الشغل حسب الحمل، فالأجزاء الـ3 اللي بتتكتب بالتوازي في التحليل بتروح لموديلات مختلفة، كل واحد بحصته.
- **تحوّط (hedging):** لو مسار ما بعتش ولا إشارة حياة (حتى ملخص التفكير) بعد ثواني (4–20 ث حسب نوع المهمة وسرعته المعتادة) بيتسابق معاه مسار تاني بحصة مختلفة، **أول إشارة حياة تكسب والتاني يتلغي**. أقصى حاجة مسارين في نفس الوقت، وما بيحصلش تكرار على نفس الموديل (مشكلة v3.23).
- بيستنى **بس لما كل المسارات نايمة**، ولحد 40 ثانية إجمالي، وبرسالة صريحة؛ ولو Google قالت «استنى أكتر من 25 ث» بيقولك «مشغول» فوراً.
- الملفات/الصور/PDF **تفضل على Gemini** دايماً (هو الوحيد اللي بيقراها).

**2 · محركات مجانية إضافية (اختياري)** (`lib/providers.js`): Groq · OpenRouter (موديلات `:free`) · Mistral. شركات تانية، حصص مستقلة تماماً عن Google. حط مفتاح (أو أكتر) من 🔑 ← «محركات مجانية إضافية»، أو وقت البناء `VITE_GROQ_API_KEY` · `VITE_OPENROUTER_API_KEY` · `VITE_MISTRAL_API_KEY` (أسرار GitHub: `GROQ_API_KEY`…). التطبيق بيكتشف الموديلات من قايمة كل شركة (مش أسماء ثابتة). طريقة الاختيار:
- **تلقائي (الافتراضي):** Gemini أولاً بنفس الجودة، والمحرك الإضافي بيدخل **بس** لو Gemini بطّأ (تحوّط) أو فشل. الدردشة والمهام الصغيرة بس.
- **جودة أولاً:** Gemini بس؛ الإضافي لو Gemini غايب فترة طويلة.
- **سرعة قصوى:** الدردشة والمهام الصغيرة على أسرع محرك متاح الأول.
دروس التحليل الطويلة والامتحانات بتفضل Gemini أولاً في كل الأوضاع (الإضافي آخر حل).

**3 · الدردشة بطيئة — 3 أسباب اتصلحوا** (`lib/chat.js` + `lib/chatflow.js` + `lib/gfiles.js`):
- كانت دايماً بتفكّر على مستوى «high». دلوقتي السؤال العادي «low»، والاعتراض/الحساب/المقارنة/«ليه» «medium».
- في مواد الدراسة كل رسالة كانت بتبعت الـPDF/الصور كاملة (لحد 14 ميجا) من جديد. دلوقتي بيترفع **مرة** وبيتفتكر 40 ساعة (Google بتحتفظ بالملف 48 ساعة).
- سياق مكتبتك كان جوه الـsystem prompt فبيتغير كل رسالة وكاش Gemini التلقائي ما بيشتغلش. دلوقتي الجزء الثابت قدام والمتغير آخر.
- **الطلبات الكبيرة** («بالتفصيل»، «شامل»، «من الصفر»، «لخّص الملف»…): خطة قصيرة (2–4 أقسام) ثم **كل قسم يتكتب في نفس اللحظة** بنفس التعليمات والعمق ويظهروا بالترتيب. وقت الرد ≈ أطول قسم مش مجموع الكل. فيه خيار إيقافه في 🔑 لو عايز توفر طلبات.

**اللي لازم تعرفه بأمانة:**
- ❌ **ما عملتش تدوير مفاتيح/مشاريع Google عن قصد:** Google بتقيّد المشاريع اللي بتعمل كده («التحايل على الحصة») وممكن تخسر مفتاحك. كل التوسّع هنا من موديلات مختلفة ومن شركات تانية، وده مسموح.
- حصة Groq المجانية حوالي **8000 توكن/دقيقة** لكل موديل، فالطلبات الكبيرة ما بتتبعتش له (بتفضل على Gemini). والرد اللي يتقطع عند حد التوكن **بيتعاد على Gemini** ومش بيتعرض ناقص.
- الباقات المجانية بتتغير (Google مبقتش تنشر أرقام كل موديل، وCerebras بقى بكريدت لازم بطاقة). شوف حدودك الفعلية في AI Studio ولوحة كل شركة.
- ⚠️ الخصوصية: الطلبات على الباقات المجانية ممكن تُستخدم لتحسين منتجات الشركة (Google بتقول كده صراحة). ما تبعتش بيانات مرضى حقيقية.
- جودة الدردشة في وضع «سرعة قصوى»: الموديلات المفتوحة (مثل gpt-oss) قوية في التفكير لكن العامية المصرية عند Gemini أحسن. لو ده يهمك خليك على «تلقائي».
- عدّاد الاستهلاك في التطبيق بيحسب طلبات Google بس؛ طلبات المحركات الإضافية منفصلة.

**اللي اتجرّب واللي ما اتجرّبش:** `npm test` = 31 اختبار على **شبكة وهمية** (Gemini وGroq متقلّدين) بتغطي: التحويل الفوري عند 429/503 · حصة يومية · التحوّط وإلغاء الخاسر · الانتظار لما كله نايم · وضع الجودة/السرعة · عدم إرسال PDF أو طلب كبير لـGroq · الرد المقطوع · مفتاح إضافي غلط · إلغاء المستخدم · تقسيم الدردشة بالتوازي · تذكّر الملفات المرفوعة. الملفات كلها اتفحصت صياغةً (TypeScript parser). **لكن ما اتعملش `vite build` ولا اتشغّل على سيرفرات Google/Groq الحقيقية أو على موبايل/ويندوز** (مفيش شبكة ولا node_modules هنا). وسلوك **CORS مع Groq/Mistral/OpenRouter** من الـWebView ما اتأكدش منه: على أندرويد لو المتصفح منعه التطبيق بيحوّل لوحده للـHTTP الأصلي (بدون بث لكنه سريع)، وعلى ويندوز اتفتحت النطاقات في `electron/main.cjs`. جرّب: `npm install && npm test && npm run dev`، حط مفتاح Groq، دوس «جرّب الاتصال»، وبعدين اسأل الدردشة سؤال وسؤال كبير. لو حاجة مش زي ما مكتوب قولي.

## v3.25 — الأسئلة والشروحات في قسمين · سجل محادثات الـ AI · روابط المصادر مع التظليل

**1 · الأسئلة في قسم والشروحات في قسم (كل قسم بمواضيعه):** في الشاشة الرئيسية فوق القايمة زرّين كبار **«الأسئلة»** و**«الشروحات»** (وعلى كل واحد عدده). كل قسم له مواضيعه هو بس، وجواه نفس الاختيارين: «حسب الموضوع» و«الكل»، وزرار «نظّم الجديد بالـ AI» بينظّم القسم اللي إنت فيه بس. الـ AI بقى بيرتّب الأسئلة لوحدها والشروحات لوحدها (طلبات منفصلة، وكل طلب بيشوف مواضيع نوعه بس)، فمفيش موضوع بيجمع النوعين. واختيار القسم بيتحفظ.
- ⚙️ **الترحيل التلقائي:** المواضيع القديمة اللي كانت جامعة أسئلة وشروحات (من نسخ قبل كده) بتتقسّم مرة واحدة أول ما تفتح التطبيق: نفس الاسم والإيموجي، موضوع للأسئلة وموضوع للشروحات. لو الموضوع القديم كان كله من نوع واحد بيفضل زي ما هو (وشرح الموضوع بتاعه كمان). التقسيم اللي بيحصل في الموضوعات المختلطة بس بيمسح «شرح الموضوع» وتقدر تكتبه تاني بضغطة.
- نقل سؤال أو شرح يدوي لموضوع (أيقونة الفولدر) بيعرض مواضيع نوعه بس.
- الكود: `lib/topics.js` (`kindOf` · `splitByKind` · `organize` لكل نوع) · `screens/Home.jsx` · `App.jsx` · `components/MoveModal.jsx` · آخر `styles.css` (`.kindtabs`).

**2 · سجل محادثات الـ AI:** تحت رأس نافذة الـ AI (ونافذة «اسأل الـ AI عن السؤال» كمان) شريط فيه:
- **🕘 السجل** (وعليه عدد المحادثات): بيفتح قايمة كل المحادثات، الأحدث فوق، باسم المحادثة (أول سؤال كتبته) وتاريخها وعدد رسايلها. دوس على أي واحدة تفتحها وتكمّل فيها، وأيقونة 🗑 جنبها بتمسحها (دوسة تانية «تأكيد؟» عشان ما تمسحش بالغلط).
- **➕ جديدة:** محادثة جديدة فاضية. القديمة بتفضل في السجل. لو كان فيه رد لسه بيتكتب بيتوقف وبيتحفظ اللي اتكتب منه.
- المحادثة بتتسجّل أول ما تبعت أول رسالة (مفيش محادثات فاضية). أيقونة الزبالة في الرأس بقت «احذف المحادثة دي».
- التخزين: لكل شات قايمة صغيرة `…:idx` + سجل لكل محادثة `…:c:<id>`. المحادثة الوحيدة القديمة (`nclex:chat:global` و`nclex:chat:<id>`) بتتنقل لوحدها لأول محادثة في السجل أول مرة تفتح الشات. النسخة الاحتياطية بتشمل كل المحادثات، واستعادتها بتدمج القوايم من غير ما تمسح اللي عندك. ولما تمسح سؤال، كل محادثاته بتتمسح معاه.
- الكود: `lib/chathist.js` (جديد) · `components/ChatPanel.jsx` · `lib/backup.js` · آخر `styles.css` (`.chat-bar` · `.chat-hist`).

**3 · روابط المصادر في رد الـ AI + تظليل الجزء:** تحت كل رد بيعتمد على حاجة من أسئلتك أو شروحاتك محفوظة بيظهر سطر **«المصادر (دوس تفتح وتتظلّل)»** فيه رابط لكل سؤال/شرح ليه علاقة بالرد (مع أيقونة النوع). لما تدوس على رابط:
- بيفتحلك السؤال أو الشرح، وبيفتح القسم اللي فيه الجزء المقصود (التفصيص · الشرح · نص السؤال…) لو كان مقفول.
- بيظلّل **الجزء اللي الرد جاي منه** (فقرة واحدة لحد 3 فقرات متقاربة) بأصفر وينزل بيك عليه في نص الشاشة، والتظليل **بيختفي لوحده بعد 8 ثواني** (بيتشال من الصفحة تماماً، مش بس بيبهت).
- طريقة تحديد الجزء: الجملة اللي الـ AI كتب جنبها المصدر بتتقارن محلياً (من غير أي طلب لجوجل) بسطور السؤال والشرح والتريكات، والأقرب هو اللي بيتظلّل. لو ما فيش تشابه كفاية بيتفتح السؤال من غير تظليل بدل ما يظلّل حاجة غلط.
- لو رجعت للشاشة بزر الرجوع بعد كده التظليل ما بيتعادش.
- الكود: `lib/library.js` (`splitCites` بقى بيرجّع الجملة · `bestField` · `bestBlocks`) · `lib/highlight.js` (جديد) · `screens/Editor.jsx` · `App.jsx` · `components/ChatPanel.jsx` · آخر `styles.css` (`.hl-flash`).

⚠️ **اللي اتجرّب واللي ما اتجرّبش:** منطق التقسيم والترحيل والتنظيم لكل نوع وتخزين السجل (ترحيل القديم، إضافة، تعديل، حذف) واختيار الجزء المظلَّل اتجرّبوا بسكريبتات اختبار، والملفات كلها اتفحصت صياغةً وأسماءً. لكن **ما اتعملش build ولا اتشغّل في متصفح أو موبايل** (مفيش `node_modules`). شغّل `npm install && npm run dev` وجرّب: ① تابات الأسئلة/الشروحات ② محادثتين والتنقل بينهم والحذف ③ سؤال للـ AI عن حاجة محفوظة ودوس على المصدر. لو لقيت حاجة مش زي ما هو مكتوب هنا قولي.

## v3.24 — خمس تعديلات (حجم الخط · النطق · كلمات B2+ · الوضع المظلم · سرعة «الشرح من الصفر»)

**1 · حجم الخط لكل فقرة:** أيقونة **Aa** في رأس كل كارت نتيجة (نص السؤال/الملخص · الكلمات · التفصيص/الشرح من الصفر · التريكات)، وفي أقسام شاشة الموضوع، وفي كل رد في الشات (ومعاه كارت الاختبار)، والقاموس، والمراجعة. دوس عليها يظهر **A− · النسبة · A+** (من 80% لـ 210%)، والنسبة نفسها بترجّع الحجم الأصلي. كل فقرة لها حجمها المستقل (التغيير بيمس نص الفقرة دي بس) والحجم بيتحفظ بعد قفل التطبيق. الكود: `lib/textscale.js` · `components/FontSizer.jsx` · آخر `styles.css` (`.ts-box`).

**2 · النطق:** السبب القديم: كل كلمة = طلب Gemini TTS، وحصته المجانية صغيرة جداً، فبعد كام ضغطة كان بيرجع لصوت الموبايل (لهجة مش أمريكية) وكل ضغطة بتستنى طلب فاشل الأول. الجديد (`lib/speech.js`): ① كاش (الكلمة اللي سمعتها بتشتغل فوراً وأوفلاين) ② **صوت أمريكي من Google** (`tl=en-US`) حوالي 0.3 ثانية، بدون مفتاح وبدون حصة ③ Gemini الرجالي كاحتياطي ④ صوت الموبايل **بس لو en-US حقيقي** (لهجة تانية مرفوضة). كلمات القايمة بتتحمّل في الخلفية (2 في المرة) فالضغطة غالباً فورية. **الصوت الافتراضي بقى أنثوي**؛ لو عايز الرجالي (Gemini): 🔑 مفتاح Gemini ← «صوت النطق» ← «أمريكي رجالي» (أبطأ وله حد يومي).

**3 · الكلمات السهلة:** السبب: الموديل كان بيحكم على المستوى «بالإحساس»، والفلتر المحلي كان فيه A1/A2 بس (B1 مفيش له فلتر). الجديد: ① لازم يكتب مستوى CEFR قبل كل كلمة `[B2]`/`[C1]`/`[C2]`/`[MED]`/`[ABBR]` وأي سطر `[A1]`/`[A2]`/`[B1]` بيتشال ② قاموس محلي للإنجليزي اليومي A1–B1 (`lib/commonwords.js`) بيشيل أي مدخل كله كلمات سهلة مهما كان المستوى اللي الموديل ادّعاه ③ المصطلحات الطبية والاختصارات (NPO, IV…) والعبارات B2+ (rule out) بتفضل. التفكير زاد من 512 لـ 1024 عشان فحص المستوى يبقى صادق. ⚠️ ده بيمس التحليلات الجديدة بس؛ الكلمات المحفوظة قبل كده زي ما هي.

**4 · الوضع المظلم:** السبب: السطور الفرعية والعناوين الفرعية كانت بلون `--ink-2/--ink-3` (تباين 10:1 و5.8:1) بوزن 400 (رفيع)، ووزن 600 كان شغال على الشاشات الكبيرة بس. الجديد: ألوان أفتح (تباين 13:1 و9:1) ووزن 600 لكل نص القراءة في الوضع المظلم على الموبايل كمان، وعناوين وكلمات مهمة أسمك.

**5 · «الشرح من الصفر» بطيء (الأهم):** السبب: القسم كان **إجابة واحدة طويلة** (1100+ كلمة، أكتر بكتير لو المادة كبيرة) بتتكتب كلمة ورا كلمة، وباقي الأقسام مستخبية وراها على الشاشة، وكل طلب كان بيعيد رفع الملف كله (لحد 14 ميجا). الجديد (`lib/lessonflow.js`) **للمواد الطويلة بس** (≈5 صفحات فأكتر): ① أول حاجة بيكتبها الطلب الرئيسي هي **خطة** بمواضيع المادة، بتتقرا وهو لسه بيكتب ② من أول ما الخطة تظهر (≈3–6 ثواني) بتبدأ **عدة شرائح (لحد 3) في نفس اللحظة**، كل شريحة بتشرح مواضيعها بـ **نفس البرومبتات ونفس العمق** (نفس بروفايل الطالب وقواعد الشرح ومعيار الجودة والأقسام) ③ الأقسام بترجع بنفس ترتيب الشرح العادي بالظبط، وبتظهر بالترتيب من غير ما النص يقفز ④ لو الموديل ما كتبش الخطة بالشكل المطلوب → شريحة واحدة للمادة كلها (لسه بالتوازي مع الباقي) ⑤ شريحة فشلت بعد إعادة المحاولة → الباقي بيفضل ظاهر ومعاه رسالة الخطأ وزر «جرّب تاني». **كمان:** الملفات الكبيرة بتترفع **مرة واحدة** على Files API ويشاور عليها كل طلب (بدل 5–9 رفعات)، ولو أي حاجة فشلت بيرجع للطريقة القديمة لوحده. المواد القصيرة بتفضل على المسار القديم.
- ⚠️ التكلفة: كل شريحة = طلب زيادة (مادة طويلة ≈ 7 طلبات بدل 5) فحصة Google اليومية بتخلص أسرع شوية. للتحكم (في `.env` أو الـ workflow): `VITE_LESSON_SLICES=0` يوقف الشرائح (الطريقة القديمة) · `=2` أو `=3` (الافتراضي) أو لحد `5` · `VITE_SLICE_MIN_PAGES=5` حد «المادة الطويلة» · `VITE_FILES_API=off` يوقف الرفع لمرة واحدة.
- اتجرّب بنسخة تجريبية للموديل (الترتيب، عدم القفز، الفشل الجزئي، الإلغاء، الرجوع للطريقة القديمة) لكن **مش على Google الحقيقي**: لو جوجل رفضت رفع الملف أو شكل الخطة طلع مختلف في الواقع، التطبيق بيرجع للطريقة القديمة تلقائياً (ومحدش يلاحظ غير إن الشرح مش أسرع).

## v3.23 — إصلاح خطأ 429 / 503 («سيرفر Google زحمة دلوقتي»)

**السبب:** كل تحليل كان بيبعت 5 طلبات لجوجل (ocr · words · solve · شرح أ · شرح ب)، وفوقهم نظام «التسابق»: لو الموديل اتأخر ثواني كان بيبدأ طلب تاني لموديل تاني **في نفس الوقت**، وبيستنى لحد 10 دقايق. جوجل بتعدّ كل طلب، فوقت الزحمة الطلبات كانت بتتضاعف والحظر بيفضل مستمر.

**الإصلاح:**
1. **إعادة المحاولة الذكية** (`withBackoff` في `src/lib/gemini.js`): عند 429 / 503 / 500 / انقطاع / رد فاضي بيستنى **2 ث ← 4 ث ← 8 ث** (+ عشوائي بسيط Jitter)، **3 محاولات بس**، وبعدها رسالة هادية «السيرفر عليه ضغط… استنى دقيقة وجرّب تاني». لو جوجل نفسها قالت «retry in 45s» بيقف فوراً من غير ما يحرق حصة. الموديلات المقفولة (404 / حصة يومية خلصت) بتتخطّى من غير انتظار.
2. **اتشال التسابق (hedging) نهائياً** — طلب واحد في كل مرة.
3. **دمج الطلبات:** الشرح + التريكات بقوا طلب واحد (بيرجّع `===EXPLANATION===` و`===TRICKS===` وبيتقسموا للكارتين، والنص لسه بيظهر وهو بيتكتب). الوضع «متوازن»: **3 طلبات بدل 5**. وضع «دقة قصوى»: 4 طلبات (حلّ صامت بموديل قوي ثم الشرح). نفس الشيء في وضع «شرح المادة».
4. **الموديل بقى متغيّر:** الافتراضي `gemini-2.5-flash`. غيّره من غير تعديل كود بـ `VITE_GEMINI_MODEL` (والقوي بـ `VITE_GEMINI_MODEL_PRO`) في `.env` أو في الـ workflow جنب `VITE_GEMINI_API_KEY`. لو جوجل قالت إن الموديل مقفول على مفتاحك، التطبيق بيتحوّل لـ `gemini-flash-latest` لوحده.
5. **مفتاح الـ API** بقى في الـ header `x-goog-api-key` بدل الـ URL.
6. `package.json`: اتضاف `@fontsource/cairo` (كان مستورد في `main.jsx` والـ build كان بيفشل من غيره).

## v3.23 (تكملة 3) — «التفصيص والتريكات» أسرع (وضع fast)

الجزء البطيء كان **الجزء ب**: طلب واحد لازم يفكّر ويحلّ السؤال ويكتب الخطوات وكل اختيار والتريكات. الحل: بعد الحلّ الصامت (ناتجه صغير) بيتقسم الجزء ب لطلبين قصيرين **بيشتغلوا مع بعض ومع الجزء أ**:
- **ب-أساسي:** الخطوات + تحليل كل اختيار + الإجابة + «لو السؤال اتغيّر».
- **ب-تريكات:** جمل الحفظ + التريكات (قصير جداً).
الوقت ≈ زمن الحلّ + زمن أطول جزء قصير، بدل جزء واحد طويل. لو الحلّ الصامت فشل، بيرجع لجزء ب واحد بيحلّ بنفسه.

الوضع بـ `VITE_LESSON_MODE`: `fast` (الافتراضي، 6 طلبات للتحليل) · `split` (4 طلبات، أبطأ) · `single` (3 طلبات، الأبطأ). لو الحصة اليومية بتخلص بسرعة، جرّب `split`.

## v3.23 (تكملة 2) — سرعة الشرح + عرض كامل

- **بطء «تفصيص السؤال والتريكات» (150 ثانية):** سببه إني دمجت الشرح كله في طلب واحد طويل (≈2000 كلمة تتكتب ورا بعض) + إعادة كتابة كاملة تلقائية لو ظهر حرف غريب (كانت بتضاعف الوقت). الحل: الشرح رجع **طلبين قصيرين بيشتغلوا في نفس اللحظة** (أ: السؤال + فك الإنجليزي + الأساس · ب: الخطوات + الاختيارات + الإجابة + التريكات) فالوقت تقريباً النصف، **واتشالت إعادة الكتابة التلقائية** (النص بيتنضف على الشاشة أصلاً). الوضع «متوازن» = 4 طلبات (ocr · كلمات · أ · ب)، «دقة قصوى» = 5 (+ حلّ صامت بموديل قوي). حماية الحصة لسه شغالة بنظام إعادة المحاولة 2/4/8 ث وبدون طلبات مكررة. (الاختيار بين الأوضاع بـ `VITE_LESSON_MODE`، شوف التكملة 3).
- **عرض النص:** رجع ياخد المساحة كلها زي النسخة القديمة (اتشال تحديد العرض)، مع التنظيم الجديد.

## v3.23 (تكملة) — قراءة أريح + نافذة الأسئلة قابلة لتغيير الحجم

1. **تنسيق النص (`rich.jsx` + آخر `styles.css`)** — بيتطبق على أي نص بيتعرض (الشرح، التريكات، الشات، شرح الامتحان، المواضيع): النقطة اللي شكلها «مصطلح — معنى — ترجمة» بقت **المصطلح في سطر لوحده بخط أثقل، وكل معنى في سطر هادي تحته** بدل سطر طويل بيتلخبط فيه العربي والإنجليزي. مسافات أوسع بين العناصر والعناوين، وعرض النص مقيّد (≈920px) عشان السطر ما يمتدش على الشاشة الكبيرة. في الشات المسافات أقل شوية.
2. **تغيير عرض نافذة «اسأل الـ AI عن السؤال»:** اسحب الحافة الداخلية للنافذة (فيها مقبض صغير) يمين/شمال. العرض بيتحفظ، ودوسة مرتين على المقبض ترجّعه للأصلي. (نافذة «AI» العامة كان فيها تغيير حجم من قبل.)

## v3.22 — فحص سرعة وجودة ردود الـ AI (تعديلات صغيرة ومحسوبة)

اتفحصت الملفات اللي في الـ patch بس (الامتحان · الرسم · الترجمة · الشات). كل تعديل هنا ليه سبب واضح، ومفيش تغيير في أي واجهة أو تخزين.

1. **الامتحان: شرح الإجابة كان ممكن يتكلم عن اختيار غلط.** الأسئلة بتتكتب وبعدين الاختيارات بتتخلط وتتعرض A B C…، فلو الموديل كتب في الشرح «Option B غلط» الطالب كان بيقرا شرح عن اختيار تاني. الحل: (أ) تعليمات للموديل ما يشيرش لاختيار بحرفه أبداً ويسمّيه بكلامه. (ب) شبكة أمان في `exam.js`: لو حرف عدّى برضه (`Option B` · `choices A and D` · `الاختيار C`) بيتنقل مع اختياره لمكانه الجديد بعد الخلط. الدالة `remapLetters` مجرّبة على حالات كتير، ومابتلمسش كلمات زي «Adoption B» أو «answer A client».
2. **الرسم: لو الموديل سابب فاصلة زيادة في الـ JSON** (غلطة شائعة) كان التطبيق بيرفض الرد ويطلب من الموديل تاني (ثواني ضايعة). دلوقتي `parseInfo` بيصلّح الفاصلة لوحده الأول، ولو لسه غلط يرجع للإعادة زي ما كان.
3. **الرسم: دقة أعلى للدروس الطويلة.** المحرك كان بيشوف أول 1500 حرف بس من الشرح، بقى بيشوف 3500 (والسؤال 2000). مدخلات أكتر بدون تأثير ملحوظ على السرعة، والصورة بتطلع أقرب لمحتوى الدرس.
4. **الترجمة:** (أ) كلمة اتترجمت قبل كده بتتحفظ في الذاكرة بعد أول مرة، فمفيش قراءة وفك لـ localStorage مع كل دبل كليك. (ب) لو أول مزوّد ترجمة بطيء، التاني بيبدأ بعد 1.5 ثانية بدل 2.5 (أول رد صالح بيكسب زي ما كان).
5. **الشات:** الردود القديمة ما بتتعملهاش إعادة رسم مع كل جزء بيوصل من الرد الجديد (`React.memo` على `RichText`). كان كل حرف جديد بيعيد تحليل ورسم كل الرسائل اللي فوق، وده بيبطّئ الشات الطويل على الموبايل. النص بيظهر بالظبط زي ما كان.

⚠️ **اللي ما اتفحصش:** التحليل والشرح والكلمات (`analysis.js` · `prompts.js` · `gemini.js` · `chat.js`) مش في الـ patch، فما اتلمسوش.

## v3.21 — معرض الصور (احفظ اللي تختاره بس، مرتّب حسب الدرس)

- **أيقونة 🔖 «احفظ» على كل صورة** بيرسمها الـ AI (فوق الصورة على الركن). دوسها = الصورة تنزل المعرض (بتتلوّن وتقول «محفوظة»)، دوسها تاني = تتشال. **مفيش أي حفظ تلقائي**: اللي مادستش عليه ما بيتحفظش.
- **شاشة «معرض الصور»** (أيقونة الصور فوق جنب الوضع الليلي، وعليها عدد الصور المحفوظة): كل درس/سؤال ليه قسم باسمه (واسم الموضوع تحته)، وجواه صوره كروت مرتبة. القسم بيتقفل ويتفتح، وزرار «افتح الدرس» بيوديك للسؤال نفسه. صور الشات العام في قسم لوحدها «من شات AI العام». بحث بالاسم لما تزيد الصور عن 4.
- كل كارت: دوس على الصورة = ملء الشاشة (مع القلم والممحاة، وكتابتك بتظهر في المعرض كمان) · ✏️ تغيّر الاسم (الاسم الافتراضي هو عنوان الرسمة) · ⬇️ تنزّل ملف على جهازك · 🔖 تشيلها من المعرض (دوسة تأكيد).
- الصور المحفوظة **منفصلة عن الشات**: تفضل حتى لو مسحت المحادثة، والصورة بتتخزن مرة واحدة (نفس الصورة ما بتتكررش). كل صورة في سجل لوحدها فالمعرض ما بيحمّلش إلا اللي ظاهر.
- زرار «حفظ الصورة» القديم اتسمّى **«تنزيل»** عشان ما يتلخبطش مع حفظ المعرض (لسه بينزّل ملف على الجهاز زي ما كان).
- لو تخزين الجهاز مليان، بتظهر رسالة صغيرة تحت الصورة ومفيش حاجة بتتكسر.
- الملفات: `src/lib/imagebank.js` (التخزين) · `src/lib/imgfile.js` (تنزيل الملف، اتنقل من ChatPanel) · `src/components/ImageGallery.jsx` (الشاشة) · تعديلات صغيرة في `ChatPanel.jsx` و`App.jsx` و`Icon.jsx` وآخر `styles.css`.

## v3.20 (تكملة 2) — القلم والممحاة على الصورة المكبّرة

لما تدوس على أي صورة وتكبّرها بيظهر شريط أدوات تحتها:
- **✏️ قلم** بـ 4 ألوان (أحمر، أزرق، أخضر، أسود) + **هايلايتر** أصفر شفاف، و3 سماكات. اكتب بالإصبع أو القلم أو الماوس.
- **🧽 ممحاة**: لمسة على أي خط تمسحه كله.
- **↶ تراجع / ↷ إعادة**، ويدعم **Ctrl+Z** للتراجع و**Ctrl+Shift+Z** أو **Ctrl+Y** للإعادة (و⌘ على الماك). كل شيء قابل للتراجع: الكتابة والمسح و«مسح الكل» 🗑️.
- اختصارات: **P** للقلم، **E** للممحاة، **Esc** للإغلاق.
- الكتابة بتتحفظ مع الصورة (حتى لو قفلت وفتحتها تاني أو قفلت التطبيق)، وبتظهر على الصورة الصغيرة في الشات، وزر حفظ الصورة بيدمجها في الـ PNG.
- الكتابة طبقة مستقلة (Canvas) فوق الصورة بإحداثيات نسبية، فبتفضل في مكانها بالظبط مهما اتغير حجم الشاشة، ومش بتأثر على أي حاجة تانية في التطبيق. الكود في `src/components/ImageInk.jsx`.

## v3.20 (تكملة) — تنويع الإنفوجراف + الترجمة تحت الإنجليزي + توقيع التطبيق

**الإنفوجراف كان بنفس الشكل دايماً**
- المحرك كان فيه ثيم واحد ثابت (ألوان، خلفية، هيدر، كروت). دلوقتي كل صورة بتاخد «لوك» عشوائي: 8 باليتات ألوان × 4 أشكال هيدر × 3 أشكال كروت × 5 خلفيات (حوالي 480 تركيبة)، ومش بيتكرر نفس الباليت مرتين ورا بعض. معنى الألوان (أحمر خطر، أخضر طبيعي…) ثابت في كل الثيمات.
- لو طلبت نفس الطلب تاني، الرسم بيطلع بلوك جديد. وتحت كل صورة زر **🎨 ستايل تاني**: نفس المحتوى بشكل مختلف فوراً من غير أي طلب للموديل. ولو كتبت «غيّر الستايل» بيحصل نفس الشيء.
- الموديل كمان بيتقاله يختار نوع تخطيط مختلف عن الصورة اللي قبلها (جدول/هرم/دورة…) لو المحتوى يسمح.

**«أعد إنشاء الصورة وحط الترجمة العربي تحت الإنجليزي» ما كانش بيشتغل، وده السبب:**
1. الجملة كانت بتتفهم كشات عادي مش طلب صورة، لأن الكشف كان بيحتاج الجملة تبدأ بـ «ارسم / اعمل صورة».
2. محرك الرسم كان ممنوع عليه عربي غير سطر واحد، والتصميم نفسه مفيهوش مكان لسطر عربي تحت كل سطر إنجليزي.
3. «أعد الإنشاء» ماكانش بيفتكر الصورة السابقة فكان بيبدأ من الصفر.

**الحل:** (أ) فهم طلبات التعديل على آخر صورة (أعد، غيّر، ضيف، ترجمة، تحت الإنجليزي…). (ب) الصورة بقت بتحتفظ بـ JSON بتاعها، والموديل بياخده ويضيف الترجمة من غير ما يغيّر المحتوى. (ج) الرسم بيدعم ترجمة عربية تحت العنوان والنقاط وخلايا الجدول والـ Tip في كل أنواع التخطيط، وبيحسب المساحة فمفيش حاجة بتتداخل أو تتقص. (د) زر **🌐 ترجمة تحت الإنجليزي** تحت أي صورة.

**التوقيع:** `BY / MOSTAFA HAMMAD WITH AI` في الركن السفلي الأيسر. مثبّت خارج تدفق الصفحة (`position: fixed` + `pointer-events: none`) فمش بيحرّك ولا بيغطي ولا بيمنع الضغط على أي عنصر، والنوافذ والـ modals بتظهر فوقه، ومخفي في الطباعة. الكود: مكوّن `Credit` في `App.jsx` وأنماط `.credit` في آخر `styles.css`.

## v3.20 — إصلاح جذري: الترجمة + بطء الامتحان

**1) الترجمة بالدبل كليك كانت بتقول «مقدرتش أترجمها»**
- **السبب الحقيقي:** نسخة الكمبيوتر (Electron) بتفتح الصفحة من `file://`، و`electron/main.cjs` كان بيضيف صلاحية CORS لسيرفر Gemini بس. رد خدمة الترجمة كان بيوصل لكن المتصفح بيحجبه، فالترجمة بتفشل والنت سليم. كمان كانت معتمدة على رابط واحد غير رسمي.
- **الحل:** (أ) `main.cjs` بقى بيسمح بسيرفرات الترجمة كمان. (ب) `wordtr.js` بيجرّب 4 مزودين مجانيين (Google ×3 ثم MyMemory)، ولو واحد فشل أو اتأخر 2.5 ثانية بيشغّل اللي بعده والأسرع يكسب. (ج) آخر حل فقط: لو كلهم فشلوا وفيه مفتاح، طلب Gemini صغير واحد (عشان تقفله: `ALLOW_GEMINI_LAST_RESORT = false`). الترجمة العادية لسه من غير توكنز، والنتيجة بتتحفظ.
- رسالة الخطأ بقت أدق، وسبب الفشل الحقيقي بيظهر لما تقف بالماوس على الرسالة وفي الـ Console.

**2) الامتحان كان بياخد دقايق**
- **السبب:** طلب واحد كبير بتفكير «high» بيكتب الأسئلة كلها ورا بعض، ومفيش حاجة بتظهر لحد ما آخر حرف يوصل.
- **الحل:** الامتحان بقى بيتقسّم لدفعات صغيرة (حوالي 3 أسئلة، بحد أقصى 4 طلبات) بتشتغل **مع بعض** بتفكير خفيف، والرد بيتقري وهو بينزل، وكل سؤال بيظهر أول ما يكتمل. أول سؤال بيظهر في ثواني وتقدر تبدأ تحل وباقي الأسئلة بتتجهز.
- كل دفعة ليها «زاوية» مختلفة (علامات · تحاليل · أولوية · أدوية · مضاعفات · تثقيف · تفويض · فئات خاصة) عشان الأسئلة ما تتكررش، وفيه كشف للتشابه، وطلب واحد تعويضي لو سؤال ضاع.
- أسئلتك المحفوظة ما بتتبعتش للامتحان إلا لو الموضوع بيطابقها أو طلبت «من أسئلتي».
- لو وقفت الامتحان أو حصل خطأ في النص، الأسئلة اللي جهزت بتفضل.
- ⚠️ الامتحان بقى بيستهلك من 1 إلى 5 طلبات بدل طلب واحد (الطلبات متوازية).

## v3.19 — حركات أكتر

- دخول سلس لكل شاشة، وقوائم الأسئلة والمجلدات والكلمات بتظهر عنصر ورا التاني.
- فقرات الشرح بتظهر بنعومة وهي بتتكتب، وأيقونة القسم اللي بيتكتب دلوقتي بتتنطط، وشريط التقدم بيلمع.
- الخلفية حية: لمبة المكتب بتتنفس والضوء الأزرق بيتحرك ببطء.
- أزرار «حلّل» و«شرح مادة» بيعدّي عليها لمعة كل كام ثانية.
- البطاقات بتطلع لفوق شوية عند المرور بالماوس، والاختيارات والنتائج والنوافذ والتنبيهات ليها حركة دخول.
- كل الحركات بتتوقف تلقائياً لو شغّلت «تقليل الحركة» في النظام.

## v3.18 — تصميم «مكتب المذاكرة الهادي»

- ألوان أنعم: أزرق ليلي (داكن) وضباب فاتح (فاتح) مع تدرّج تيل/أزرق، ووهج دافئ خفيف في الركن كأنه لمبة مكتب.
- بطاقات أكبر وأخف، شريط ملوّن رفيع لكل قسم، أيقونات بتدرّج، أزرار بتتحرك بلُطف عند المرور.
- شريط تمرير رفيع بلون التطبيق، وسطور أريح للقراءة الطويلة.
- حركة واحدة فقط: دخول الترحيب في الصفحة الرئيسية، وبتتوقف مع إعداد «تقليل الحركة».

## v3.17 — إصلاح قائمة الكلمات في وضع «شرح المادة» (سقف 90 كلمة ورجوع التعليمات الخاصة بالمادة بعد تعديل B2)

## v3.16 — الكلمات الجديدة بقت من مستوى B2 فما فوق (A1 و A2 و B1 كلها مستبعدة)

## v3.15 — قائمة الكلمات (B1 فما فوق فعلاً)

- البرومبت بقى بيحكم على المستوى بقوائم CEFR الرسمية (Oxford 3000/5000 و English Vocabulary Profile) مش بإحساس الموديل بالصعوبة، وأي كلمة مش متأكد إنها B1+ بتتحذف.
- قايمة الاستبعاد اتوسعت بأمثلة صريحة، والفلتر المحلي للكلمات السهلة (A1/A2) اتوسع كمان.
- مهمة الكلمات بقت بتفكّر شوية قبل ما تكتب، ومابتروحش لموديل lite إلا لو الأقوى واقعين أكتر من 45 ثانية (موديلات lite هي اللي كانت بتدخل كلمات سهلة).

## v3.14 — حل جذري لخطأ 503 ("Google مشغولة")

- **سبب المشكلة:** خطأ 503 معناه إن موديل معيّن عند Google زحمة لحظياً (والمفاتيح المجانية أولويتها أقل). التطبيق كان بيجرّب كل موديل مرة واحدة وبعدين يظهر الخطأ، وكمان لو الرد انقطع في النص كان بيوقف.
- **الحل:** إعادة محاولة تلقائية بانتظار متزايد (1.5 ← 3 ← 6 ← 12 ← 20 ثانية) مع تبديل بين الموديلات، ولوحة صحة مشتركة بحيث لو موديل وقع كل المهام التانية تتخطاه فوراً.
- لو الرد انقطع في النص، بيكمّل لوحده من غير ما النص اللي على الشاشة يرجع لورا.
- الموديلات الـ lite ما بتجاوبش على مهام الشرح إلا لو الموديلات الأقوى فشلت أكتر من 45 ثانية (للحفاظ على الجودة). OCR والكلمات مسموح لها فوراً.
- الخطأ الأحمر ما بيظهرش إلا لو Google فاضلة واقعة 10 دقايق، أو المفتاح غلط، أو الحصة اليومية خلصت. أثناء المحاولة بتظهر رسالة هادية بدل الخطأ.

# ClinixStudy (تطبيق أندرويد)

## الطريقة (من غير Android Studio)
1. اعمل Repository جديد على GitHub (يفضّل **Private**).
2. ارفع كل **محتويات** الفولدر ده (مش الفولدر نفسه): لازم `package.json` و`src` و`.github` يبقوا ظاهرين في أول صفحة الـ Repository.
   - لو لقيت الملفات جوه فولدر فرعي (زي `clinixstudy-app/`) الـ workflows دلوقتي بتلاقيه لوحدها وتشتغل عادي، بس الأفضل تبقى في الجذر.
   - `.github` لازم يكون في جذر الـ Repository (مش جوه فولدر فرعي) وإلا GitHub مش هيشغّل الـ workflows.
3. افتح تبويب **Actions** ← **Build APK** ← **Run workflow** (بيشتغل لوحده كمان مع أي push).
4. استنى ~5–8 دقايق، افتح الـ run الأخضر ← من تحت **Artifacts** نزّل `ClinixStudy-apk`.
5. فك الضغط، انقل `app-debug.apk` للموبايل وثبّته (اسمح بالتثبيت من مصدر غير معروف).
   - بياناتك القديمة (أسئلة + كلمات + المفتاح) بتفضل زي ما هي لو ثبّته فوق النسخة القديمة.

## مفتاح Gemini
- افتح التطبيق ← دوس أيقونة 🔑 فوق ← الصق المفتاح مرة واحدة. بيتحفظ على موبايلك بس.
- (اختياري) تقدر تضيفه كـ Secret باسم `GEMINI_API_KEY` في Settings ← Secrets ← Actions عشان يتدمج وقت البناء.
- **متحطوش المفتاح جوه الكود في Repo عام**، لأن جوجل بتكتشف المفاتيح المسرّبة وبتوقفها.

## v3.13 — حل جذري لخطأ الموديل 404 + الترجمة من جوجل بس + ترجمة الجُمل
**1) خطأ `HTTP 404 · gemini-2.5-pro is no longer available to new users`**
- **السبب:** جوجل لسه بتعرض موديلات `gemini-2.5-*` في قايمة الموديلات، لكن بترد 404 على أي مفتاح ما استخدمهاش قبل كده. التطبيق كان بيجرّب الموديلات واحد ورا التاني، ولما كلهم يفشلوا كان بيعرض خطأ **آخر** موديل جرّبه (2.5-pro) حتى لو السبب الحقيقي حاجة تانية (حد الطلبات مثلاً).
- **الحل:**
  - الموديلات القديمة (2.x) بتتشال من القوائم لو فيه جيل 3 متاح، والقوائم الافتراضية بقت على الأسماء المتجددة `gemini-flash-latest` و`gemini-pro-latest` فمش بتتقفل.
  - لو موديل رجّع «no longer available»، التطبيق بيقراه من رسالة جوجل نفسها **الموديل البديل** (مثلاً `gemini-3.1-pro-preview`) ويجرّبه فوراً، ويفتكره للتحليلات الجاية.
  - الموديل المقفول بيتفتكر **أسبوع** ومش بيتجرّب تاني، وقايمة الموديلات بتتحدّث لوحدها في الخلفية.
  - لو كل الموديلات فشلت، الرسالة اللي بتظهر هي **الأكثر فايدة** (حد الطلبات / السيرفر / النت) مش آخر 404، وتحتها سطر صغير بيقول كل موديل رد بإيه.
  - رسالة حد الطلبات اليومي بقت مفصولة عن حد الدقيقة.
- ملحوظة: «دقة قصوى» محتاجة Pro، وبعض المفاتيح المجانية ما بتدّيش Pro. وقتها التطبيق بيكمّل بأفضل موديل Flash لوحده.

**2) ترجمة الكلمة (دبل كليك):** بقت **ترجمة جوجل بس**، ومش بتتحوّل لـ Gemini خالص (صفر توكنز). النتيجة بتتحفظ فالكلمة المكررة ما بتتطلبش تاني، ومش محتاجة مفتاح.

**3) ترجمة الجُمل:** حدّد (بالسحب أو بالضغط المطوّل على الموبايل) أي جملة إنجليزي، تظهر فقاعة فيها **الترجمة العربي + أيقونة السماعة** (نفس سماعة الكلمات بنفس التحكم في السرعة). الجملة المحدّدة لازم تكون كلمتين أو أكتر (الكلمة الواحدة بالدبل كليك زي ما هي). الترجمة من جوجل بس، والنطق نفس نطق الكلمات.

## إزاي التحليل بقى سريع (v2.1)
**المشكلة القديمة:** التفصيص كان طلب واحد طويل بيتكتب بالتسلسل من موديل Pro. وقت الكتابة = طول النص ÷ سرعة الموديل، والعربي بياخد tokens أكتر، فكل ما الشرح يبقى أغنى كل ما يتأخر.

**الحل:** وقت التحليل دلوقتي = أطول مرحلة، مش مجموع كل حاجة. الشغل اتقسّم على 5 طلبات، اللي مش معتمد على حاجة بيبدأ في نفس اللحظة:

| المرحلة | الموديل | بتعمل إيه | بتبدأ |
|---|---|---|---|
| قراءة الصورة (OCR) | سريع، من غير تفكير | نص السؤال (وبتفهم أسئلة Next-Gen) | فوراً |
| الكلمات | سريع، من غير تفكير | **كل** كلمة فوق A2 | فوراً |
| **الحل** (solve) | حسب الوضع، **بيفكّر** | الإجابة + حكم على كل اختيار (ملخّص صغير جداً) | فوراً |
| الشرح A | سريع | السؤال بيسأل إيه + فك الإنجليزي + الأساس من الصفر | فوراً (مش محتاج الإجابة) |
| الشرح B + التريكات | سريع | الخطوات + كل اختيار + الإجابة + الجمل للحفظ | أول ما "الحل" يخلص |

- **الدقة:** التفكير العميق متركّز في مرحلة الحل بس، ومرحلة الكتابة بتاخد الإجابة المتأكَّد منها كحقيقة ثابتة، فمفيش تناقض بين أجزاء الشرح. لو الثقة مش عالية بيظهر تنبيه ⚠️.
- **الأوضاع:** متوازن (الافتراضي — Flash بتفكير متوسط) · دقة قصوى (Pro بأعلى تفكير). (وضع "فائق السرعة" اتشال في v2.6.)
- **لو الحل فشل** مرحلة B بتحلّ السؤال بنفسها، فالشرح بيكمّل في كل الأحوال.
- النتيجة بتظهر **أثناء ما بتتكتب**، وجزء A بيتقري وانت مستني جزء B.
- **التفكير ما بيتحسبش "تعطيل":** بنطلب ملخّصات التفكير من Gemini كعلامة إن الموديل شغّال، فمش بيتشغّل موديل تاني على الفاضي. ولو موديل وقع وهو بيفكّر، التاني بيبدأ قبل ما تشوف أي حاجة.
- التعليمات الثابتة في `systemInstruction` عشان الـ cache الضمني بتاع Gemini يوفّر وقت القراءة.
- الموديلات اللي مش متاحة لمفتاحك (مثلاً Pro على المفتاح المجاني) بتتفكّر 6 ساعات حتى بعد قفل التطبيق، فمفيش طلب ضايع عليها.
- **القياس الحقيقي:** بعد كل تحليل بيظهر سطر ⏱ تحت "خلص التحليل" بيقولك الوقت الفعلي لكل مرحلة (قراءة / كلمات / حلّ / أساس / تفصيص)، عشان لو لسه في بطء نعرف هو فين بالظبط.
- مؤشر التقدّم بيتعلّم من سرعة موبايلك الحقيقية.
- ⚠️ كل تحليل دلوقتي **5 طلبات** (كان 3). لو مفتاحك مجاني وعليه حد يومي للطلبات، ده بيقلّل عدد الأسئلة في اليوم.

## تحديثات v2.7 (شاشة السؤال من غير شريط سفلي)
الشريط اللي كان تحت في شاشة السؤال اتشال بالكامل (Regenerate + علامة الحفظ + شريط التقدّم الصغير)، والمساحة اتفضّت للمذاكرة من غير أي حاجة تشتّت.
- أثناء التحليل التقدّم وزرار **إيقاف التحليل** لسه موجودين في كارت "جاري التحليل" فوق النتايج.
- مفيش Regenerate: التحليل بيتعمل مرة من زرار "حلّل السؤال". لو جزء اتحلّل غلط أو فشل، زرار "إعادة المحاولة" جنبه بيعيد الجزء ده بس.
- الحفظ لسه تلقائي (v2.6).

## تحديثات v2.6 (وضعين بس + حفظ تلقائي)
1. **وضعين بس:** اتشال وضع "فائق السرعة". فاضل **متوازن** و**دقة قصوى**. لو كنت مختار "فائق السرعة" قبل كده، التطبيق بيرجع لوحده على "متوازن".
2. **الحفظ تلقائي:** زرار "حفظ السؤال" اتشال. أول ما التحليل يخلص السؤال بيتحفظ لوحده ويظهر في قايمة الأسئلة (ومعاه الكلمات الجديدة في القاموس + رسالة التشجيع زي ما كانت)، وأنت فاضل في نفس الشاشة.
   - مفيش أي علامة ولا رسالة وقت الحفظ العادي (غير رسالة أول حفظ). لو الحفظ فشل فعلاً بتظهر رسالة حمرا فوق.
   - أي تعديل بعد كده (على نص النتيجة، العنوان، التعليمات، أو تغيير الصورة) بيتحفظ لوحده بعد ثانية تقريباً من ما توقف كتابة، على **نفس السؤال** (من غير نسخ مكررة). ولو خرجت من الشاشة أو قفلت التطبيق على طول بيتحفظ فوراً.
   - لو دوست **إيقاف** في نص التحليل، النتيجة الناقصة **مش بتتحفظ** لوحدها. ولو جزء بس فشل، السؤال بيتحفظ والزرار "إعادة المحاولة" بيحدّثه بعدين.
   - زرار "حذف السؤال" بيظهر بعد أول حفظ.

## تحديثات v2.5 (شاشة بداية احترافية)
**المشكلة:** أول ما تفتح التطبيق كانت بتظهر شاشة فاتحة جداً (قريبة من الأبيض) من غير أي حاجة عليها لحد ما التطبيق يجهز.

**دلوقتي:** أيقونة التطبيق (خط النبض + ClinixStudy) على خلفية تيل بنفس لون الأيقونة، من أول لحظة، وبعد ما أول شاشة في التطبيق تترسم بالكامل بتتلاشى الشاشة دي في ثلث ثانية والتطبيق ظاهر تحتها جاهز.
- شاشة أندرويد الأصلية بتفضل ظاهرة لحد ما التطبيق يبقى جاهز (إضافة `@capacitor/splash-screen` مع `launchAutoHide: false`)، فمفيش لحظة بيضا أو نص تحميل في النص.
- الأيقونة المستخدمة هي `resources/splash_icon.png` (بتتنسخ لمشروع أندرويد في خطوة `Launch splash` في الـ workflow). لون الخلفية `#1CA3BE` موجود في `capacitor.config.json` و`index.html` وخطوة الـ workflow، لو غيّرته غيّره في التلاتة.
- أقل مدة للشاشة ثانية واحدة عشان متبقاش وميض سريع: `MIN_VISIBLE_MS` في `src/lib/splash.js`.
- لو حصل أي خلل، الشاشة بتتشال لوحدها بعد 5 ثواني كحد أقصى.

## تحديثات v2.4 (تحفيز ومذاكرة أريح)
- **رسالة ترحيب ذكية** فوق الشاشة الرئيسية بتتغيّر حسب وضعك (أول مرة / في النص / خلّصت الهدف / لسه مبدأتش). لو غبت يوم مفيش لوم، بس خطوة صغيرة تبدأ بيها.
- **كارت واحد للتقدّم:** حلقة هدف اليوم (بتتملي أول ما تفتح) + شريط آخر 7 أيام (✓ على كل يوم ذاكرت فيه) + **مستوى** بيتحدد من عدد أسئلتك (طالب جديد ← متدرّب ← ممرض واعد ← شبه جاهز ← محترف ← جاهز للامتحان) مع شريط بيقولك فاضل كام للمستوى الجاي. العتبات في `LEVELS` جوه `src/lib/motivation.js`.
- **احتفال بعد الحفظ:** رسالة بتقولك وصلت فين، وكونفيتي خفيف في اللحظات الكبيرة بس (تحقيق الهدف · ترقية مستوى · 3/7/14/30/60/100 يوم ورا بعض). مفيش حركة لمن مفعّل "تقليل الحركة" في الموبايل.
- **كلمة النهاردة:** كلمة من قاموسك بتفضل ثابتة طول اليوم وبتتغيّر بكرة، مع النطق، وزرار "كلمة تانية".
- **شكل أهدى:** خلفية ناعمة لأعلى الشاشة، وأقسام الصفحة بتدخل واحد ورا التاني بحركة هادية.

## تحديثات v2.3
1. **تحميل النطق أسرع:** الطلب الواحد بيتشارك (لو الكلمة بتتحمّل في الخلفية وانت دوست عليها بتستنى نفس الطلب بدل طلب جديد)، وأثناء ما بتسمع كلمة بيتحمّل أول **كلمتين بعدها** في الخلفية، وأول 3 كلمات بيتحمّلوا لما تفتح قسم الكلمات. نفس الكلمة بتتخزّن فمش بتتحمّل تاني. لو جيميناي رجّع "طلبات كتير" الـ prefetch بيوقف دقيقة لوحده.
2. **التحكم في السرعة:** تحت كل أيقونة 🔊 أيقونة صغيرة بتغيّر السرعة بالترتيب 0.5× ← 0.75× ← 1× ← 1.25×. السرعة واحدة لكل الأيقونات ومتحفوظة بعد قفل التطبيق، والصوت بيحافظ على طبقته (مش بيتقلب صوت تخين لما يبطّأ).
3. ~~فتح التطبيق من غير صورة~~ (اتبدّل في v2.5: رجعت شاشة بداية بأيقونة التطبيق، شوف تحت).
4. **فقرات بتتقفل وتتفتح:** كل فقرة (نص السؤال · الكلمات · التفصيص · التريكات) ليها سهم. دوس على السهم أو على العنوان: بتفتح/تنكمش. الأسئلة المحفوظة بتفتح **متقفلة** عشان تتنقل بينها بسرعة، والتحليل الجديد بيفتح الفقرات وهي بتتكتب.

## نطق الكلمات (v2.2)
- جنب كل كلمة (وكل جملة للحفظ) أيقونة 🔊. دوسها = تسمع الكلمة، دوسها وهي شغّالة = توقف.
- **الصوت:** رجل بلهجة أمريكية (en-US) من موديل الصوت بتاع Gemini (`gemini-3.1-flash-tts-preview`، وبيجرّب `gemini-2.5-flash-preview-tts` لو الأول مش متاح). الصوت والأسلوب ثابتين على أي موبايل، مش بيعتمد على صوت الجهاز.
- **مرة واحدة بس:** كل كلمة بتتنزّل أول مرة وبعدها بتتخزّن على الموبايل (IndexedDB)، فتشتغل أوفلاين ومبتستهلكش طلبات تاني.
- **بيقرا الإنجليزي بس:** أي عربي جوه السطر بيتشال قبل النطق.
- **لو Gemini مش متاح** (مفيش مفتاح / مفيش نت / وصلت للحد): بيرجع لصوت الموبايل وبيختار صوت رجالي en-US لو موجود. ولو مفيش أي صوت بيظهر تنبيه.
- لتغيير الصوت: `VOICE` في `src/lib/speech.js` (`Orus` / `Iapetus` / `Puck` / `Fenrir` كلهم رجالي). بعد التغيير الكلمات الجديدة بس هي اللي هتتنزّل بالصوت الجديد.
- ⚠️ كل كلمة جديدة = طلب Gemini واحد (مرة واحدة بس لكل كلمة).

## شكل شاشة التحليل (v2.2)
شاشة المراقبة الداكنة (أخضر نيون) اتبدّلت بكارت فاتح بنفس لغة باقي التطبيق: شريط تيل جانبي زي كروت النتايج، أيقونة قلب، خط ECG تيل هادي، شريط تقدّم بتدرّج التيل ← السماوي، وشارات المراحل بتتحوّل من رمادي ← تيل (شغّالة) ← أخضر مع ✓ (خلصت). نفس الشكل في الشريط السفلي، وبيتبع الوضع الليلي تلقائياً.

## هيكل الكود
```
src/
  main.jsx            إقلاع التطبيق (ينتظر الخط + البيانات بالتوازي قبل أول رسم)
  App.jsx             التنقل + الحفظ + الثيم
  styles.css          نظام التصميم (فاتح/ليلي)
  screens/            Home · Editor · WordsScreen
  components/         Progress (شاشة المراقبة) · rich (عرض النص) · ui · Icon
  lib/
    speech.js         النطق الأمريكي (Gemini TTS + كاش + صوت الموبايل كبديل)
    gemini.js         الشبكة: streaming + hedging + fallback + علامات الحياة
    analysis.js       خط الإنتاج: حل ∥ شرح A → شرح B (+ OCR والكلمات)
    prompts.js        البرومبتات (OCR / الكلمات / الحل / الشرح A / الشرح B)
    progress.js       حساب النسبة والوقت المتبقي
    parse.js · storage.js · image.js · config.js
```

## التشغيل على الكمبيوتر
```
npm install
npm run dev
```

## نسخة الكمبيوتر (Windows)
نفس التطبيق بالظبط، متغلّف بـ Electron (مفيش أي تغيير في فولدر `src`).

**من غير ما تسطّب أي حاجة (الأسهل):**
1. ارفع المشروع على GitHub زي ما بتعمل مع الـ APK.
2. تبويب **Actions** ← **Build Desktop (Windows)** ← **Run workflow**.
3. بعد ~4–6 دقايق نزّل `ClinixStudy-windows` من **Artifacts**، وفيه:
   - `ClinixStudy-Setup-*.exe` → مثبّت عادي (قايمة Start + أيقونة سطح المكتب).
   - `ClinixStudy-Portable-*.exe` → ملف واحد يشتغل بدوبل كليك من غير تثبيت.

**أو على جهازك (محتاج Node 20+):**
```
npm install
npm run desktop          # تشغيل مباشر للتجربة
npm run desktop:build    # بيطلّع الـ exe جوه فولدر release/
```
- مفتاح Gemini بتحطه مرة واحدة من أيقونة 🔑 زي الموبايل.
- بيانات الكمبيوتر **منفصلة** عن الموبايل (أسئلة وكلمات كل جهاز لوحده).
- `Alt + ←` = رجوع (زي زرار الرجوع في أندرويد).

### تخطيط الكمبيوتر (شاشة عريضة ≥ 1000px)
نفس ترتيب الموبايل (كل حاجة تحت بعضها) لكن بعرض الشاشة كله: فقرة التفصيص والنص والكلمات كل واحدة بعرض النافذة، وخط أكبر شوية للقراية. التعديلات في آخر `src/styles.css`، والموبايل ما اتغيّرش.

## رفع PDF أو ملف نصي (مش صور بس)
- في شاشة السؤال تقدر ترفع: **صورة** · **PDF** (لحد 10 ميجا) · **ملف نصي** `.txt` / `.md`، بالاختيار أو السحب أو Ctrl+V (للصور والـ PDF).
- النتيجة نفس الأقسام بالظبط: نص السؤال · كلمات جديدة · تفصيص السؤال · التريكات.
- لو الملف فيه أكتر من سؤال: افتح «عنوان وتعليمات إضافية» واكتب مثلاً «السؤال رقم 5» أو «الصفحة 3»، وإلا هيحلل أول سؤال كامل.
- الملف نفسه بيتحفظ مع السؤال، فإعادة المحاولة بعد ما ترجع للسؤال شغالة.
- ملفات Word / PowerPoint مش مدعومة حالياً (صدّرها PDF الأول).

## دردشة مع الـ AI عن السؤال 💬
- بعد ما التحليل يخلص بيظهر زرار **«اسأل الـ AI»** تحت على الشمال (أيقونة فقط على الموبايل).
- بيفتح لوحة جانبية (ملء الشاشة على الموبايل) تقدر فيها: تطلب شرح أعمق، تسأل ليه اختيار غلط، تطلب مثال شبهه، أو **تعترض** على الإجابة (الـ AI بيراجعها من الأول: لو غلط بيعترف ويصحّحها، ولو صح بيثبت بالدليل).
- بيرد بنفس لغتك (بالبلدي المصري لو بتكتب عربي) وبيكتب الرد وهو بيتولّد، وتقدر توقفه.
- المحادثة بتتحفظ مع السؤال وبتتمسح لما تمسح السؤال. `Enter` إرسال، `Shift+Enter` سطر جديد، `Esc` إغلاق.

## تصحيح الحروف المكسورة (حل جذري)
`src/lib/text.js`: كل نص بيكتبه الـ AI، وكل نص بيتعرض (حتى الأسئلة المحفوظة قبل كده)، بيعدّي على منظّف بيشيل أسباب كسر الحروف العربية: رموز Presentation Forms وحروف `ﬁ` الملزقة، حروف فارسية شبه العربية (ی ک ھ)، علامات الاتجاه والمسافات الخفية (ZWNJ/LRM/RLM…)، التطويل والتشكيل، والأرقام الفارسية.

## خانتين منفصلتين: سؤال · شرح (v2.9)
**أضف سؤالاً** (للأسئلة) و**أضف شرحاً** (للمواد: كتب، ملازم، سلايدات، صور، نص) من الشاشة الرئيسية. الاتنين بيستقبلوا:
- **أي عدد ملفات (لحد 12)** مع بعض: صور · PDF · Word `.docx` · PowerPoint `.pptx` · Excel `.xlsx` · كتب EPUB · OpenDocument · RTF · HTML · TXT/MD/CSV/JSON…
- **نص مكتوب أو ملصوق مباشرة** (مربع «أو اكتب / الصق»)، أو Ctrl+V في أي مكان في الشاشة ينزل النص كمصدر.
- الاتنين مع بعض: مثلاً 3 صور + PDF + نص من عندك في تحليل واحد.
- ملفات الصوت والفيديو وصيغ Office القديمة (`.doc` `.ppt` `.xls`) مش مدعومة (احفظها بالصيغة الحديثة أو PDF).

**الشرح** بيطلّع نفس الأربع كروت لكن للمادة: ملخص المادة · كلمات جديدة · الشرح من الصفر (مع إنجليزي كتير) · نقاط الحفظ والفخاخ. ودردشة الـ AI شغّالة عليها وبتشوف الملفات نفسها. بيتحفظوا مع الأسئلة وعليهم علامة «شرح 📖».

## الرموز الغريبة: حل جذري تاني
السبب الحقيقي: الـ AI أحياناً بيحط حرف من لغة تانية (هندي/تايلاندي/روسي/عبري/صيني… أو حرف عربي نادر زي ڭ) في نص الكلمة، فالخط ما بيعرفوش ويرسمه بخط تاني ودايرة منقّطة. دلوقتي `text.js` بيشتغل بنظام «قايمة مسموحة»: عربي قياسي + إنجليزي + يوناني (رموز طبية) + أرقام + رموز وإيموجي، وأي حاجة تانية بتتشال، والحروف العربية النادرة بتتحوّل لأقرب حرف قياسي (ڭ→نج، ڤ→ف، پ→ب، چ→تش). وكمان كل prompts فيها قاعدة صريحة بمنع كتابة أي لغة تانية.

## v3.0 — إيه الجديد
- **ربط الأسئلة ببعض:** التحليل بيشوف أسئلتك وشروحاتك القديمة، ولو السؤال الجديد ليه علاقة بسؤال قديم بيكتب جملة قصيرة **بهايلايتر أصفر 🔗** جوه نفس السطر اللي فيه المعلومة المرتبطة (مش في فقرة لوحدها ومش متجمّعة في مكان واحد). مفيش علاقة حقيقية = مفيش حاجة.
- **الحروف الإنجليزي في أماكنها:** السبب كان تقسيم الكلمة لقطعتين عند علامات الـ **bold**، فكل قطعة إنجليزي كانت بتتحط لوحدها وبتتعكس (`ibrocartilage F`). دلوقتي أي عبارة إنجليزي بتتعرض **قطعة واحدة** مهما كان فيها تنسيق، والتنسيق اللي بيلمس كلمة بيغطيها كلها (`src/lib/emphasis.js`).
- **الرموز الغريبة (للمرة التالتة وبجذورها):** الحرف اللاتيني الملزوق جوه الكلمة العربية (`ك`+`ps`+`ولة`) بيتشال، وفلتر اللغات الغريبة والحروف العربية النادرة شغّال، وكمان لو الرد فيه الحاجات دي بيتطلب **إعادة كتابة نضيفة تلقائياً مرة واحدة**، والـ prompts فيها قاعدة صريحة.
- **جودة الرد:** برومبتات احترافية جديدة فيها «معيار جودة» (آلية الجسم قبل القاعدة، أرقام وقيم محددة، عدسة الـ NCLEX وخطوة الـ Clinical Judgment، «لو السؤال اتغيّر»، تحقق ذاتي قبل الكتابة)، والحل بيتعمل مرتين بشكل مستقل ويتقارن، وأطوال الشرح تقريباً ضعف اللي كانت (المتوازن 680/980 كلمة، الدقة القصوى 850/1300). الجزء الأول من الشرح بيفكّر قبل ما يكتب (بيشتغل جنب حلّ السؤال فمفيش تأخير). الباقي متوازي ومتدفّق زي ما هو.
- **شريط الاستهلاك** جوه نافذة المفتاح 🔑: عدد الطلبات النهاردة ووقت التجديد (12 بالليل بتوقيت المحيط الهادئ). لو Google رجّعت «Quota exceeded» التطبيق بيتعلّم الحد الحقيقي لوحده.
- **دبل كليك (أو دبل تاب) على أي كلمة إنجليزي** → فقاعة صغيرة دايرية فيها السماعة + التحكم في السرعة + المعنى بالعربي (بيتحفظ فلو كلمة اتفتحت قبل كده بتظهر فوراً).
- **الدردشة:** رفع ملفات وصور (📎، أو لصق، أو سحب)، و**إنشاء صور** (زرار 🖼️، أو اكتب «ارسم…»). إنشاء الصور محتاج حساب مدفوع (Billing) في Google AI Studio.
- **أسلوب الشرح:** أيقونات جنب كل اختيار + اختيارين جداد: **لخّص** و**ترجم كل الإنجليزي** (كل جملة إنجليزي ومعناها العربي جنبها).
- شلت «موصى به» من الوضع المتوازن، وشلت الثواني المتوقعة (من أزرار الأوضاع ومن «فاضل كذا ثانية»).



## v3.3
- **إصلاح جذري:** خطأ "is not a function" (ترجمة الكلمة، رسم الصور، التنظيم) سببه إن `runTask` بينادي `onText` من غير ما يتأكد إنه موجود. اتصلّح مرة واحدة في `gemini.js` لكل المستدعين.
- **وقت الحفظ** (اليوم · التاريخ · الساعة والدقيقة، من غير ثواني) على كل سؤال في القوائم وفي شاشة السؤال.
- **الكلمات في مستوى B1:** القايمة بتطلّع الكلمات اللي فوق B1 + المصطلحات الطبية (غيّر ده في `buildWordsPrompt` جوه `src/lib/prompts.js`).
- **تصنيف الكلمات:** تحت كل كلمة ⭐ مهمة جدا / ✓ مهمة / ✕ مش مهمة. اللي مش مصنّف ما بيتحفظش في القاموس. القاموس فيه نافذتين (مهمة جدا · مهمة) + نافذة للكلمات القديمة لحد ما تصنّفها. فلتر فوق قايمة كلمات السؤال.
- **أي كلمة** تدوس عليها مرتين (ترجمة + نطق) تقدر تصنّفها وتحفظها من نفس الفقاعة.
- **استهلاك أقل:** مفيش تحميل نطق مسبق (طلب واحد فقط لما تدوس السماعة)، ومعاني الكلمات اللي التطبيق عارفها بتظهر من غير أي طلب، والتنظيم التلقائي بيتأجّل لحد ما تخرج من السؤال وبيجمّع الأسئلة الجديدة في طلب واحد، وفهرس الشات أخف.

## v3.2 — مواضيع ذكية · AI عام · اسأل AI بيشوف كل أسئلتك
1. **تجميع بالموضوع:** الـ AI بيجمّع الأسئلة والشروحات والملفات والصور اللي عن نفس الموضوع (طلب واحد لكل 50 عنصر). الرئيسية فيها تبويب «حسب الموضوع». جوه الموضوع: **شرح شامل** بيربط كل اللي ذاكرته، الأسئلة والشروحات، **معرض كل الملفات والصور**، وكلمات الموضوع. في أي سؤال شريط **السابق / التالي** جوه موضوعه. التنظيم تلقائي بعد الحفظ (ممكن توقفه) أو زرار «نظّم الجديد». نقل أي عنصر بإيدك (📁) بيتثبّت ومش بيتحرك تاني. تكلفة: طلب Gemini واحد لكل دفعة تنظيم.
2. **اسأل AI** (جوه السؤال) بقى بيشوف كل أسئلتك: فهرس بكل العناصر + النص الكامل لأقرب 6 عناصر لسؤالك (بحث محلي بدون طلبات زيادة). الرد بيعرض «من أسئلتك» كأزرار تفتح السؤال المصدر.
3. **أيقونة AI** فوق (كل الشاشات): شرح أي موضوع، **امتحانات تفاعلية** (اكتب «اعملي امتحان 10 أسئلة على القلب» أو زرار ✅؛ من أسئلتك أو من أي موضوع؛ اختيار واحد وSATA، نتيجة ونقاط ضعف)، تلخيص، رسم، رفع ملفات. النافذة **قابلة للتحجيم**: اسحب الحافة العلوية/الجانبية/الركن، أزرار ص/م/ك، ملء الشاشة (دبل كليك على الهيدر)، والحجم بيتحفظ. على الموبايل ورقة سفلية بنفس التحكم.

## v3.1 — رسم الصور بالمفتاح المجاني
Google **مبتدّيش** رسم الصور لأي مفتاح مجاني (مؤكد من صفحة الأسعار ومن موظفين Google). فالدردشة (زرار 🖼️) فيها 3 طرق وبتجرّب بالترتيب لحد ما واحدة تنجح:
1. **رسم توضيحي** (الافتراضي، مجاني بالمفتاح العادي): Gemini النصية بتكتب رسمة SVG: مخططات بعناوين إنجليزي مكتوبة صح، سلاسل سبب ونتيجة، دورات، جداول، كروت حفظ. بتتحفظ PNG.
2. **صورة فنية AI** (مجاني بدون مفتاح): موديل FLUX عن طريق Pollinations.ai. الصورة مفيهاش كلام (الموديلات دي بتغلط في الإملاء). بحد حوالي صورة كل 15 ثانية، والوصف بس بيتبعت للخدمة دي.
3. **Gemini 💳**: موديلات Google نفسها، بتشتغل لو المفتاح فيه Billing. لو ما اشتغلتش بينزل تلقائياً على 2 ثم 1.

آخر اختيار بيتحفظ، وتحت كل صورة مكتوب اتعملت بأنهي طريقة.

## v3.4
- الكلمات: كل كلمة في مستوى B1 **أو أعلى** + المصطلحات الطبية (بس A1/A2 بتتستبعد).
- الدبل كليك على أي كلمة إنجليزي في رد الـ AI بيفتح: سماعة + ترجمة + تصنيف (اتجرّب).
- أي مفتاح API جديد = عدّاد الاستهلاك والحد المتعلَّم من المفتاح القديم بيتمسحوا والعدّ يبدأ من صفر.
- حذف أي كلمة من القاموس، أو من فقرة «كلمات جديدة» في السؤال (وبتتشال من القاموس كمان).
- الجودة: الشات والامتحانات بيفكّروا أعمق (high/4096) بنفس عدد الطلبات.

## v3.5 — أكتر من سؤال في رفعة واحدة
- ارفع صور/ملفات لأسئلة كتير مرة واحدة: طلب صغير واحد بيكتشف الأسئلة، وبعدين كل سؤال بيتحلل لوحده (5 مراحل كاملة) ويتحفظ سؤال مستقل بعنوان «س7 · …».
- خانة «ملاحظات للذكاء الاصطناعي» بقت ظاهرة: اكتب «حلل السؤال 1 و7 و8 بس» والباقي بيتتجاهل تمامًا. من غير ملاحظة = كل الأسئلة.
- الشرح: «من صفحة 20 لـ 50 بس» أو «الفصل 3 بس» بيلتزم بيه في الملخص والشرح والكلمات ويتجاهل الباقي.
- لوحة منظمة بتعرض كل سؤال وحالته وزر «افتح»؛ والأسئلة بتتنظم تلقائي في مواضيع.

## v3.6
- 💾 نسخة احتياطية (أيقونة الحفظ فوق): تحفظ كل الأسئلة والصور والكلمات والمواضيع والشات في ملف JSON وتسترجعها (دمج من غير مسح). مفتاح Gemini مش بيتحفظ.
- 🔁 مراجعة الكلمات (زر «راجع» في القاموس): كروت بنظام التكرار المتباعد؛ «عرفتها» تؤجل الكلمة (يوم ← 3 ← 7 ← 14 ← 30)، «لسه» ترجعها بعد 10 دقايق. من غير أي طلب لـ Gemini.

## حل مشاكل البناء على GitHub
**`npm error enoent Could not read package.json ... no such file or directory`**
- السبب: الـ Repository مفيهوش `package.json` في المكان اللي الـ workflow بيشتغل منه (غالباً الملفات اترفعت جوه فولدر فرعي، أو ملف `package.json` ماترفعش).
- الحل: النسخة دي من الـ workflows بتدوّر على `package.json` أوتوماتيك (خطوة `Locate project folder`). لو الخطوة دي نفسها فشلت، يبقى المشروع فعلاً مش مرفوع: ارفع محتويات الفولدر كلها (بما فيها `package.json`) على الـ branch اللي اسمه `main` أو `master`.

